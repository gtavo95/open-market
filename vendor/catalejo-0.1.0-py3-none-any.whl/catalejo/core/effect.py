"""Los efectos como dato, y el intérprete que dice qué significa moverlos.

# El efecto no se guarda

Lo que viaja en el Log, en el canal `effects`, son las MOVIDAS: proponer, completar
los argumentos, y lo que el host devuelve, hecho o rechazado. El estado de cada
efecto se calcula plegándolas con `effects_of`, igual que el plan se calcula
plegando `steps` con `project`. De ahí sale la misma propiedad: por la ley del
fold, `fold(s, a ++ b) == fold(fold(s, a), b)`, así que el host puede guardar el
canal al final de lo anterior y cada turno arranca con la historia sin que nadie
le pase un estado. Un `status` que se mutara no cabe en un Log donde nadie borra.

# `apply_effect` es el único árbitro

Es el único lugar donde un verbo significa algo, y devuelve la MISMA tupla cuando
el op no aplica: un `propose` repetido, un `done` sobre lo que ya está hecho, un
`resolve` sobre lo que ya se cerró. Así repetir una movida es gratis, que es lo
que hace inofensivo que el host siembre dos veces el mismo `done` o que `retry`
corra dos veces la célula que propone.

# `done` lo emite el host

Adentro del turno nadie ejecuta nada. Una célula propone (`propose_effects`), otra
completa los argumentos con código (`resolve_args`), y el host, en el borde, manda el
PDF o la cuenta y siembra el `done` o el `reject` en el turno siguiente. Adentro,
un efecto quedaría fuera de las leyes: `retry` lo mandaría dos veces y `boundary`
tiraría el paso con el PDF ya enviado. Es la regla de `docs/diseno.md`: una
capacidad con efectos va detrás de una aprobación explícita, nunca como un
builtin más del REPL.

# `args` es una tupla de pares

Un dict rompe `frozen` (no tiene hash) y la igualdad canónica que `normal()` y
las leyes necesitan. Los pares van ordenados y sin repetir, y `resolve` los UNE
en vez de pisarlos por clave: dos fichas citadas son dos pares `("path", ...)`,
y el host lee todos. Un arg no se corrige, se agrega; el que lo emite es código
determinista y el efecto se cierra en el turno siguiente.

# `result` es lo que el host dice que produjo

Un `done` o un `reject` puede traer `args`: la URL del link de pago, las fichas
que salieron. El fold los guarda en `result` del efecto cerrado, con la misma
forma canónica que `args`, y no en `args`, porque `args` es lo que se pidió
enviar y mezclarlos borraría la diferencia entre lo pedido y lo que salió. El
primer cierre manda: un segundo `done` con otro resultado devuelve la misma
tupla, como cualquier movida sobre un efecto cerrado. Desde el 28 de septiembre
de 2026; hasta entonces el fold tiraba los `args` de un cierre y el resultado
solo viajaba como texto en `note`.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from functools import reduce

Args = tuple[tuple[str, str], ...]
"""Pares (clave, valor) ordenados y sin repetir. `("path", "productos/x.md")`."""

VERBS = frozenset({"propose", "resolve", "done", "reject"})

PROPOSED = "proposed"
DONE = "done"
REJECTED = "rejected"


@dataclass(frozen=True, slots=True)
class EffectOp:
    """Una movida sobre los efectos. Es lo que viaja en el canal `effects`.

    Un solo tipo para los cuatro verbos, con los campos que cada uno usa, por la
    misma razón que `PlanOp`: lo que hay que hacer con esto es plegarlo.
    `propose` trae `kind`; `propose` y `resolve` traen `args`; `done` y `reject`
    traen `note` (el motivo, en texto) y pueden traer `args` con lo que el envío
    produjo (la URL, el id de la cita), que el fold guarda en `result`.
    """

    verb: str
    id: str = ""
    kind: str = ""
    args: Args = ()
    note: str = ""


@dataclass(frozen=True, slots=True)
class Effect:
    """Lo que sale del fold: un efecto con su estado. Nunca viaja en el Log."""

    id: str
    kind: str
    args: Args = ()
    status: str = PROPOSED
    note: str = ""
    result: Args = ()


@dataclass(frozen=True, slots=True)
class Intent:
    """Una fila de la tabla del host: qué efecto y qué le pregunta al juez para proponerlo.

    `asked` es el nombre de la pregunta que dice si el cliente lo pidió;
    `requires` son más nombres al mismo juez, y todos tienen que llegar al umbral
    para que se proponga. Son nombres al juez y no lecturas del plan porque así
    hay un solo mecanismo y un solo umbral, y la memo del juez los hace gratis.
    """

    kind: str
    asked: str
    requires: tuple[str, ...] = ()


Effects = tuple[Effect, ...]


def find_effect(effects: Effects, id: str) -> Effect | None:
    return next((e for e in effects if e.id == id), None)


def joined(a: Args, b: Args) -> Args:
    """La unión ordenada de dos juegos de args, sin repetir."""
    return tuple(sorted(set(a) | set(b)))


def apply_effect(effects: Effects, op: EffectOp) -> Effects:
    """Los efectos después del op, o la misma tupla si el op no aplica.

    Un verbo desconocido, un id que no existe, un `propose` repetido y una
    movida sobre un efecto que ya no está propuesto salen todos por la misma
    puerta: devolver la tupla intacta. Quien tenga que distinguir compara.
    """
    if not op.id or op.verb not in VERBS:
        return effects
    found = find_effect(effects, op.id)
    if op.verb == "propose":
        if found is not None:
            return effects
        return (*effects, Effect(op.id, op.kind, joined((), op.args)))
    if found is None or found.status != PROPOSED:
        return effects
    if op.verb == "resolve":
        args = joined(found.args, op.args)
        if args == found.args:
            return effects
        moved = replace(found, args=args)
    else:
        status = DONE if op.verb == "done" else REJECTED
        moved = replace(found, status=status, note=op.note, result=joined((), op.args))
    return tuple(moved if e.id == op.id else e for e in effects)


def effects_of(ops: tuple[EffectOp, ...]) -> Effects:
    """Los efectos que resultan de todas las movidas, en orden. Un fold, y nada más."""
    return reduce(apply_effect, ops, ())


def proposed(effects: Effects) -> Effects:
    """Lo que sigue propuesto: lo que el host todavía no ejecutó ni rechazó."""
    return tuple(e for e in effects if e.status == PROPOSED)
