"""La checklist como dato, y el intérprete que dice qué significa moverla.

# El plan no se guarda

Lo que viaja en el Log son los OPS. El plan se calcula plegándolos, y de ahí sale
la propiedad que lo hace componible: por la ley del fold,
`fold(s, a ++ b) == fold(fold(s, a), b)`, y como `then` le pasa a cada célula
`merge(seen, acc)`, cada una proyecta el plan tal como estaba cuando corrió sin
que nadie se lo pase. Dos células que tocan el plan en el mismo paso no se pisan.

# `apply` es el único árbitro

Es el único lugar donde un verbo significa algo. Un op que no cambia nada no
aplica, y por eso `apply` devuelve el MISMO plan cuando no aplica: es cómo se
detecta, sin una segunda tabla de reglas que se desincronice. Hasta el 20 de
septiembre de 2026 esa comparación la hacía `admit`, que juzgaba lo que el
modelo proponía desde el REPL; está en el historial antes de `f1b1ce6`, con su
tabla de verbos por flexibilidad. El agente vivo no deja que el modelo mueva el plan: lo
siembra el host y lo cierra el juez.

# `done` lo emite el juez

Un paso con compuerta lo cierra `close_by_gate`, que emite el `mark` por él.
Que haya un solo emisor del `done` es toda la garantía que da este módulo: "el
plan está completo" no es otra forma de decir "el modelo dijo que terminó", que
es la terminación que ya teníamos y la razón por la que esto existe. Un paso sin
compuerta hoy no lo cierra nadie (`cobro` en la venta de agro): el día que un
hecho lo cierre, ese hecho es una compuerta más.

# Las etapas se calculan, no se guardan

Un plan con dos niveles (la venta: diagnosticar, cobrar, facturar; y adentro de
cada una sus partes) es el mismo plan plano con un campo `padre` en cada paso,
igual que `objetivos` de agro tiene `padre` para las plagas. `apply` sigue
siendo tres verbos y `project` sigue siendo un reduce. Lo que sale de ahí son
funciones: una etapa está cerrada cuando todos sus hijos lo están, la etapa
activa es la primera abierta, y la hoja activa es su primer hijo abierto. Nadie
mantiene ese estado, así que nadie lo puede desincronizar. Anidar planes adentro
de planes daría lo mismo y costaría más: `apply` caminaría un árbol.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from functools import reduce

STATUSES = frozenset({"todo", "active", "done", "skipped"})

CLOSED = frozenset({"done", "skipped"})


@dataclass(frozen=True, slots=True)
class Step:
    """Un paso: qué hay que hacer, cómo va, y qué lo cierra.

    `done_when` nombra una pregunta para el juez. Vacío quiere decir que
    nadie lo cierra por ahora.

    `padre` es el id de la etapa que contiene a este paso, o vacío en la raíz.
    """

    id: str
    intent: str = ""
    status: str = "todo"
    done_when: str = ""
    padre: str = ""


type Plan = tuple[Step, ...]


@dataclass(frozen=True, slots=True)
class PlanOp:
    """Una movida sobre el plan. Es lo que viaja en los canales `steps` y `course`.

    Un solo tipo para los tres verbos, con los campos que cada uno usa. Tres
    dataclasses y una unión describirían mejor lo que es y harían peor lo que hay
    que hacer con esto, que es plegarlo: `apply` sería un `match` sobre tipos.
    """

    verb: str
    id: str = ""
    intent: str = ""
    status: str = ""
    done_when: str = ""
    padre: str = ""


@dataclass(frozen=True, slots=True)
class Outlined:
    """Un paso declarado, con sus hijos adentro: lo que `step` y `stage` arman y `outline` aplana."""

    id: str
    intent: str
    done_when: str = ""
    children: tuple[Outlined, ...] = ()


def step(id: str, intent: str, *, done_when: str = "") -> Outlined:
    """Una hoja: algo que hacer y, si lo tiene, el nombre que la cierra."""
    return Outlined(id, intent, done_when)


def stage(id: str, intent: str, *children: Outlined) -> Outlined:
    """Una etapa con sus pasos adentro. Se cierra cuando se cierran todos (ver `closed`)."""
    return Outlined(id, intent, children=children)


def outline(*nodes: Outlined, padre: str = "") -> tuple[PlanOp, ...]:
    """Los `add_step` que siembran el plan declarado, cada etapa antes que sus pasos.

    Es para escribir un plan como se lee, con la sangría haciendo de jerarquía,
    y sembrarlo igual que siempre: lo que sale son ops, y `project` los pliega
    en el mismo plan plano con `padre`. El `padre` de cada paso lo pone el
    anidamiento, así que no hay un id de etapa escrito a mano que pueda quedar
    mal. No valida ids repetidos: `apply` ignora el segundo `add_step`, como
    con ops escritos a mano.

        outline(
            stage("pago", "cobrar",
                step("medio", "link o transferencia", done_when="dijo_medio_de_pago"),
                step("cobro", "darle el link o la cuenta"),
            ),
        )
    """
    ops: list[PlanOp] = []
    for n in nodes:
        ops.append(PlanOp("add_step", n.id, n.intent, done_when=n.done_when, padre=padre))
        ops.extend(outline(*n.children, padre=n.id))
    return tuple(ops)


def find_step(plan: Plan, id: str) -> Step | None:
    return next((s for s in plan if s.id == id), None)


def move(plan: Plan, id: str, status: str) -> Plan:
    """El plan con ese paso en ese estado, o el mismo plan si no hay nada que mover."""
    if status not in STATUSES:
        return plan
    step = find_step(plan, id)
    if step is None or step.status == status:
        return plan
    return tuple(replace(s, status=status) if s.id == id else s for s in plan)


def apply(plan: Plan, op: PlanOp) -> Plan:
    """El plan después del op, o el mismo plan si el op no aplica.

    Un verbo desconocido, un id que no existe y un estado que no existe salen
    todos por la misma puerta: devolver el plan intacto. Quien tenga que
    distinguir "no aplica" de "aplicó" compara.
    """
    if op.verb == "add_step":
        if not op.id or find_step(plan, op.id) is not None:
            return plan
        return (*plan, Step(op.id, op.intent, "todo", op.done_when, op.padre))
    if op.verb == "mark":
        return move(plan, op.id, op.status)
    if op.verb == "skip":
        return move(plan, op.id, "skipped")
    return plan


def project(steps: tuple[PlanOp, ...]) -> Plan:
    """El plan que resulta de todos los ops, en orden. Un fold, y nada más."""
    return reduce(apply, steps, ())


def children(plan: Plan, id: str) -> Plan:
    return tuple(s for s in plan if s.padre == id)


def shadowed(plan: Plan, step: Step) -> bool:
    """Si alguna etapa por encima está cerrada por su propio estado."""
    while step.padre:
        above = find_step(plan, step.padre)
        if above is None:
            return False
        if above.status in CLOSED:
            return True
        step = above
    return False


def closed(plan: Plan, step: Step) -> bool:
    """Si el paso está cerrado: por su estado, por el de una etapa de arriba, o por sus hijos.

    Una etapa marcada `skipped` está cerrada aunque tenga hijos abiertos, y sus
    hijos quedan cerrados con ella: saltar la facturación es saltar sus datos.
    Una etapa en `todo` con todos los hijos cerrados está cerrada igual, sin que
    nadie la marque. El estado manda cuando dice cerrado; los hijos mandan cuando
    no dice nada. Mirar hacia arriba solo por estado, y no por hijos, es lo que
    evita que el padre pregunte por el hijo y el hijo por el padre.
    """
    if step.status in CLOSED or shadowed(plan, step):
        return True
    below = children(plan, step.id)
    return bool(below) and all(closed(plan, h) for h in below)


def active(plan: Plan, padre: str = "") -> Step | None:
    """La hoja activa: el primer paso raíz abierto, bajando por su primer hijo abierto.

    Se busca por `padre` y no por orden del plan porque un hijo que se agrega
    después va al final del canal: en orden plano, una hoja nueva de la primera
    etapa quedaría después de las hojas de la última.
    """
    for s in plan:
        if s.padre == padre and not closed(plan, s):
            return active(plan, s.id) if children(plan, s.id) else s
    return None


def pending(plan: Plan) -> Plan:
    """Lo que sigue abierto. Sobre el plan vacío es vacío: una checklist vacía no exige nada."""
    return tuple(s for s in plan if not closed(plan, s))


def close_by_gate(plan: Plan, fulfilled: frozenset[str]) -> tuple[PlanOp, ...]:
    """Los `done` que emite la máquina, uno por paso cuya compuerta ya se cumple.

    Salen como ops y no como una mutación del plan a propósito: así el plan sigue
    siendo el pliegue del canal y no una función de canal más estado del mundo. El
    día que haga falta reconstruir el plan de un turno viejo, alcanza con el canal.
    """
    return tuple(
        PlanOp("mark", s.id, status="done")
        for s in plan
        if s.done_when and s.done_when in fulfilled and s.status not in CLOSED
    )
