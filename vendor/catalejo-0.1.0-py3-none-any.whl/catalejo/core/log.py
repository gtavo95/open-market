"""Un solo tipo de dato y una sola operación.

El estado del agente y la propuesta de una célula tienen la misma forma. No son
tipos distintos, es el mismo tipo mirado con distinto alcance, y por eso una sola
`merge` sirve adentro de un paso y entre pasos.

Los errores viven adentro del Log, en `fails`. Un ejecutor que reventó es un
hecho sobre el turno, igual que algo que se dijo. Por eso ninguna función de este
módulo levanta una excepción.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from enum import IntEnum
from typing import Literal

from .effect import EffectOp
from .memory import Memory, join
from .message import Conversation
from .plan import PlanOp


@dataclass(frozen=True, slots=True, order=True)
class Fail:
    """Algo que no funcionó. Un hecho, no una razón para abandonar el turno.

    Una célula lo reporta y quien la compuso decide si es fatal.

    `who` es quién lo reportó, y cada borde que cruza le antepone el nombre del
    alcance: el `loop` de un buscador llamado `catalogo` sale como
    `catalogo/loop`. Así un fallo adentro de una célula compuesta no se confunde
    con el mismo fallo afuera, y con dos buscadores se sabe cuál fue. Los que
    leen `who` para decidir (una muestra perdida es `model`, un turno sin
    consultar es `grounding`) miran `role_name`, que es el último tramo.
    """

    who: str
    reason: str

    @property
    def role_name(self) -> str:
        """Quién falló, sin el camino que le pusieron los bordes: `catalogo/model` es `model`."""
        return self.who.rsplit("/", 1)[-1]


@dataclass(frozen=True, slots=True)
class Report:
    """Lo que una célula compuesta trae cuando otra la mandó a buscar.

    Es el colapso que `rlm()` hace fuera de tipo, devolviendo un `str`, traído
    adentro del álgebra: un buscador entero corre, y lo que cruza su borde es
    esto y no su transcripción. `who` lo firma, porque dos buscadores en
    paralelo hablan en el mismo Log y el que redacta tiene que saber de qué
    fuente viene cada cosa. `text` es su última prosa. `sources` son las rutas
    del corpus que citó y existen, ya canónicas: el que redacta las abre
    enteras, porque un informe que solo resumiera sería teléfono descompuesto.
    `is_grounded` dice si consultó algo (`reads > 0` en su Log), que es lo que decide
    si una recomendación puede salir de ahí.

    `spent` no le hace falta al que redacta y ninguna célula lo lee; es la
    etiqueta de cuánto costó este informe, y queda en dos lugares a propósito,
    como número que suma en `Log.spent` y como etiqueta acá, igual que
    `Fail.who` etiqueta un fallo sin que el fallo deje de contar.

    La transcripción del buscador no viaja acá. Hasta el 17 de septiembre de
    2026 tenía un campo `said`, "para el auditor", y eso era una segunda pila
    de mensajes adentro del Log que ninguna célula leía pero cualquiera podía.
    Lo que el borde tira y el host igual necesita se guarda en la fuente, en
    el `Dossier` de `cells/report.py`, como `Metered` guarda el gasto de un
    sub-agente: afuera del tipo, donde una célula no llega.
    """

    who: str
    text: str
    sources: tuple[str, ...] = ()
    is_grounded: bool = False
    spent: int = 0


class Status(IntEnum):
    """El voto sobre si el turno terminó.

    Está ordenado, y juntar dos votos es tomar el mayor: si alguien dice que
    falta información, falta información, sin importar quién votó último. Ese
    orden es lo que hace el canal seguro de juntar en cualquier orden, que es lo
    que después deja paralelizar.

    HALT es el único absorbente del álgebra, y está acá porque sin él CONTINUE
    manda y ninguna célula puede decir "pará". Es el voto de un juez que ve algo
    que no se arregla con otra vuelta: una inyección, una respuesta que no puede
    salir. No reintroduce el error como cortocircuito, que es lo que este diseño
    descartó, porque frena el turno siguiente y no el que está corriendo. Las
    células ya cableadas de este paso corren igual y lo que dijeron y lo que
    falló aterriza igual: los otros canales no se enteran de que alguien votó
    HALT.
    """

    QUIET = 0
    DONE = 1
    CONTINUE = 2
    HALT = 3


@dataclass(frozen=True, slots=True)
class Log:
    """Todo lo dicho, en canales. Cada canal trae su propia álgebra.

    said   una lista. El orden es el significado, así que solo concatena.
    steps  una lista. Los ops que movieron el plan del turno, en orden.
    course una lista. Los ops que movieron el plan de la conversación, en orden.
    reports una lista. Lo que trajo cada buscador, en el orden en que se cablearon.
    effects una lista. Las movidas de los efectos que el host ejecuta, en orden.
    fails  un conjunto. El mismo error reportado dos veces es un error.
    vote   el máximo del orden de Status.
    spent  una suma. Los tokens que costó todo esto.
    reads  una suma. Cuántas veces el REPL devolvió algo.
    memory un conjunto. Los mensajes y nodos de la memoria del contacto.

    `steps` no es el plan, son las MOVIDAS del plan. El plan se calcula
    plegándolas con `project`, así que no hay una copia que pueda quedar
    desincronizada y cada célula ve el plan tal como estaba cuando corrió. Trae
    un tipo propio por la misma razón que `said` trae `Message`: el álgebra ya
    declara la forma de lo que viaja.

    `course` es el mismo tipo con otro alcance: las movidas del plan que dura la
    conversación entera, la venta con sus etapas. Dos canales del mismo tipo que
    se distinguen solo por lo que significan, como `spent` y `reads` son dos
    enteros que se suman. Es uno de los dos canales que el host siembra, con
    `effects`: el Log arranca limpio en `reads`, `said` y `fails` en cada turno,
    que es lo que `grounded` necesita, y `course` entra con la historia de la
    venta y sale con lo que este turno le agregó. Por la ley del fold, guardar
    eso al final de lo anterior da el mismo plan que si todo hubiera pasado en
    un solo turno.

    `effects` es el otro canal de movidas que dura la conversación: lo que el
    agente propone que el host haga (mandar la ficha, mandar la cuenta), con sus
    argumentos, y lo que el host contestó, hecho o rechazado. El estado de cada
    efecto es el pliegue con `effects_of`, y nadie adentro del turno ejecuta
    nada: `propose_effects` propone por juicio, `resolve_args` completa por código, y el
    host siembra el resultado en el turno siguiente, como siembra `course`.
    Concatena: dos `propose` son dos, y el fold es el que hace inofensivo
    repetir el mismo.

    `reads` es el canal que dice si la respuesta tiene de dónde salir. En cero, el
    modelo no consultó nada y lo que conteste sale de su memoria, no del contexto.
    Es un piso, no una prueba: cuenta que el REPL devolvió algo, no que eso que
    devolvió tenga que ver con lo que después se afirma.

    `reports` es el canal por donde una célula compuesta le habla a otra sin
    hablar. Un buscador que sale por `boundary(..., report(...))` deja acá su
    `Report` y se lleva su `said`, así que el que viene después lee un informe
    firmado en vez de una transcripción ajena. Concatena, como `course`: dos
    buscadores son dos informes, no uno.

    `memory` es la memoria del contacto entre sesiones: los mensajes del log y los
    nodos del árbol de resúmenes (ver `memory.py`). Desde el 5 de octubre de 2026.
    Lo siembra el host, como `course` y `effects`, pero ninguna célula le agrega
    nada: el Log que vuelve la trae vacía y el agente sigue sin estado. Es un
    conjunto, como `fails`, porque el mismo nodo sembrado dos veces es uno.
    """

    said: Conversation = ()
    steps: tuple[PlanOp, ...] = ()
    course: tuple[PlanOp, ...] = ()
    reports: tuple[Report, ...] = ()
    effects: tuple[EffectOp, ...] = ()
    fails: tuple[Fail, ...] = ()
    vote: Status = Status.QUIET
    spent: int = 0
    reads: int = 0
    memory: Memory = ()


ZERO = Log()


def merge(a: Log, b: Log) -> Log:
    """La única operación. Asociativa, con ZERO como neutro.

    En todo menos `said` es además conmutativa. Idempotente lo es solo en `fails`,
    `vote` y `memory`: `said`, los planes, los informes y `effects` son listas, `spent` y
    `reads` son sumas, y todas dicen la verdad. Repetir una respuesta la duplica,
    reintentar cuesta plata, consultar dos veces son dos consultas, y dos
    `propose` son dos movidas (que el fold hace inofensivas, no `merge`).

    Esa frontera es exactamente la que dice qué se puede correr en paralelo y qué
    se puede reintentar gratis.

    Agregar un canal es agregar una línea acá, no un `if` en el engine.
    """
    return Log(
        said=a.said + b.said,
        steps=a.steps + b.steps,
        course=a.course + b.course,
        reports=a.reports + b.reports,
        effects=a.effects + b.effects,
        fails=tuple(sorted(set(a.fails) | set(b.fails))),
        vote=max(a.vote, b.vote),
        spent=a.spent + b.spent,
        reads=a.reads + b.reads,
        memory=join(a.memory, b.memory),
    )


def normal(log: Log) -> Log:
    """Lleva un Log escrito a mano a la forma canónica que produce merge.

    Las leyes valen entre logs normales: la idempotencia necesita la entrada ya
    deduplicada y la igualdad necesita un orden fijo. Juntar con ZERO es cómo se
    llega.
    """
    return merge(ZERO, log)


type Rule = Callable[[Log], Log]

type Channel = Literal["said", "steps", "course", "reports", "effects", "fails", "vote", "spent", "reads", "memory"]


def drop(*channels: Channel) -> Rule:
    """Vacía canales, dejando el resto como estaba.

    El vacío de cada canal lo saca de ZERO, así que agregar un canal sigue
    siendo una línea en `merge` y ninguna acá.

    Es un homomorfismo de monoide: vaciar la suma es lo mismo que sumar los
    vaciados, `h(a • b) == h(a) • h(b)`. Por eso se puede aplicar adentro o
    afuera de una acumulación sin que el resultado cambie, que es lo que la
    hace segura de mover de lugar. Una regla que colapse un canal en vez de
    vaciarlo, como quedarse con el último dicho, no lo es, y esas van una sola
    vez en el borde y nunca adentro de una acumulación.

    `drop("spent")` es la que hay que mirar dos veces: le esconde el gasto al
    presupuesto del padre y ahí el árbol se financia solo. Vale cuando ese gasto
    ya se contó en otro lado, como el que `Metered` mide en la fuente, y no vale
    para que las cuentas den lindas.
    """
    empties = {channel: getattr(ZERO, channel) for channel in channels}

    def dropped(log: Log) -> Log:
        return replace(log, **empties)

    return dropped
