"""La memoria de un contacto como dato: los mensajes del log y los nodos del árbol.

Es la forma de la spec de OptChat (gist de Victor Taelin, 91837951a5ce5b38f341ec1ba1df6449,
§2 y §3): un log append-only con cada mensaje tal cual, y un árbol binario de resúmenes de
una línea donde el nodo `(l, i)` cubre los mensajes `[i·2^l, (i+1)·2^l)`. El nivel 0 resume
un mensaje y cada padre une exactamente a sus dos hijos.

# Quién la escribe

El host. La genera y la guarda afuera (en agro, chatservices), y la siembra en el canal
`memory` del `Log` al empezar el turno, como siembra `course` y `effects`. Adentro del turno
ninguna célula la escribe: el `Log` que vuelve la trae vacía, y el agente sigue sin estado.
Una célula la lee (`rlm/memory.py`, `memory_search`) y lo que cruza su borde es un `Report`.

# Por qué un canal y no otra cosa

Una célula es `Log -> Log` y el REPL de un buscador se arma adentro de la célula en cada
turno, así que lo que cambia por pedido solo puede llegar por el `Log`. En `said` la verían
todos los papeles con modelo, que es lo contrario del patrón del handle: el contexto grande
vive en el REPL, no en el prompt. En `reports` no va porque `reports` es lo que SALE de un
buscador.

# Cómo se junta

Como conjunto, igual que `fails`: el mismo mensaje o el mismo nodo dos veces es uno. Conmuta
y es idempotente. El orden canónico es primero los mensajes por `i`, después los nodos por
`(l, i)`, y lo da `memory_key`, porque dos tipos distintos no se comparan entre sí.

La vista no es un canal ni se guarda: se pliega de esto cada vez (`rlm/memory.py`, `view`),
como el plan se pliega de `steps` con `project`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Entry:
    """Un mensaje del log, tal cual. `i` es su posición y su id para siempre.

    `kind` dice quién habló, con las palabras del host (en agro: `cliente`, `asesor`,
    `operador`, `evento`). `date` es ISO 8601; vacío si el host no la tiene.
    """

    i: int
    kind: str
    text: str
    date: str = ""


@dataclass(frozen=True, slots=True)
class Node:
    """Un nodo del árbol ya armado: `(l, i)` cubre los mensajes `[i·2^l, (i+1)·2^l)`."""

    l: int  # noqa: E741 — es la `l` de la spec, nivel del árbol
    i: int
    text: str


type Memory = tuple[Entry | Node, ...]


def memory_key(item: Entry | Node) -> tuple[int, int, int, str, str, str]:
    """El orden canónico: los mensajes por `i` primero, después los nodos por `(l, i)`."""
    if isinstance(item, Entry):
        return (0, item.i, 0, item.kind, item.text, item.date)
    return (1, item.l, item.i, item.text, "", "")


def join(a: Memory, b: Memory) -> Memory:
    """La unión de dos memorias, sin repetidos y en el orden canónico."""
    return tuple(sorted(set(a) | set(b), key=memory_key))
