"""El cableado del orquestador, con nombre: buscadores que traen, una que redacta, y el plan afuera de los dos.

Como `drive`, no le agrega nada al álgebra. Es una función de células a célula,
y existe para que el patrón tenga un lugar donde leerse y para que el eval mida
el mismo cableado que el host y no una copia.

# El patrón

Una célula compuesta como la de `agro.py` hacía todo en un loop: buscar en el
catálogo, razonar la venta, citar, redactar. Sumar una segunda fuente ahí
adentro es meter otro contrato en el mismo prompt y otra razón para no
terminar en el mismo loop. Acá se parte en tres papeles:

    then(*antes, fanout(*buscadores), redactora, *despues)

Los BUSCADORES buscan y traen. Cada uno es una célula compuesta entera, con su
loop y su REPL, y sale por `boundary(..., informe(...))`: su transcripción no
cruza, cruza un `Report` firmado con la prosa y las fuentes que citó. No saben
que hay una venta, y por eso su prompt es más corto y su terminación no
depende de nada que no sea encontrar.

La REDACTORA escribe la respuesta. Lee los informes, abre las fuentes enteras
y habla con la voz del negocio: la equivalencia por manzana, la seguridad, la
línea de venta al final. Es la única que le habla al cliente.

Los de ANTES y DESPUÉS son del orquestador, y ahí vive el plan. `seed` y
`close_steps` sobre `course` corren a la entrada, para saber en qué etapa está la
venta con lo que el cliente acaba de decir, y a la salida, para cerrar las
compuertas que dependen de lo que pasó en el turno. `seed` corre dos veces sin
sembrar dos veces porque mira el canal, y en `after` ya trae lo de `before`.

# Por qué así y no de otra forma

Una célula por PREGUNTA, no por estructura de datos. El catálogo y la
ontología de plagas no son dos buscadores: la ontología es un puntero al
catálogo, y buscar en paralelo lo que se alimenta en serie es pagar dos loops
para perder el camino corto. Lo que sí va en `fanout` es una fuente que
contesta otra pregunta, como las buenas prácticas de un cultivo.

El plan va afuera porque las compuertas de la venta son predicados sobre el
Log, no sobre el REPL: leen lo que dijo el cliente y si alguien consultó algo.
No necesitan estar adentro de ningún loop, y adentro obligaban a cada buscador
a cargar con la venta.

La redactora hace falta porque los buscadores no le hablan al cliente. Lo que
le cuesta es un salto más entre la ficha y la respuesta, y por eso el informe
lleva las fuentes y `render_reports` las abre enteras: la redactora lee la
ficha, no el resumen del buscador.

# Lo que el álgebra ya resuelve

`spent` se suma solo. `fails` se une sola, y cada uno cruza firmado con el
nombre del buscador. `reads` cruza el borde de cada buscador y de nadie más:
la redactora sale por `drop("reads")`, porque su REPL no tiene corpus, y así
el canal sigue diciendo lo que dice, que alguien consultó el corpus. Es lo que
lee la compuerta del orquestador que cierra "buscar". `course` y `effects` los
mueven solo `before` y `after`, así que un buscador no puede tocar la venta, ni
proponer un envío, ni por accidente.
`only(...)` alrededor de un buscador es el ruteo: `seen.course` en el `fanout`
ya trae lo de `before`, así que la etapa de la venta decide quién trabaja este
turno, y eso es también el control de costo cuando haya más de una fuente.

No es un loop. Los loops viven adentro de cada buscador y de la redactora;
esto los ordena.
"""

from __future__ import annotations

from collections.abc import Sequence

from catalejo.core import Cell, fanout, then


def orchestrate(
    searchers: Sequence[Cell],
    writer: Cell,
    *,
    before: Sequence[Cell] = (),
    after: Sequence[Cell] = (),
) -> Cell:
    """`then(*antes, fanout(*buscadores), redactora, *despues)`, con los papeles nombrados.

    `searchers` corren al mismo tiempo y cada uno ve lo mismo: lo que llegó más
    lo que agregaron los de `before`. Se espera que cada uno salga por
    `boundary(..., informe(...))`; uno que hable en `said` va a mezclarse con la
    redactora, y el álgebra no lo impide.

    `writer` ve los informes de todos en `seen.reports`, y lo que dice es lo
    que sale del turno.

    `before` y `after` son las células del orquestador: las que mueven el plan
    de la conversación, las que trazan. Con cero buscadores, `fanout()` no agrega
    nada y la redactora escribe sin informes, que es lo que pasa en el turno que
    no tiene nada que buscar.
    """
    return then(*before, fanout(*searchers), writer, *after)
