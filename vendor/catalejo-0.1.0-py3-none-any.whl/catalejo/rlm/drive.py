"""El cableado del agente de REPL, con nombre.

`then(worker, executor, grounded)` adentro de un `loop` estaba escrito a mano en
`agro.py` y en `evals.py`, o sea que el eval medía una copia del agente y no el
agente. Nombrarlo es todo lo que hace este módulo, y no le agrega nada al álgebra:
es una función de células a célula, del mismo tipo que `then` o `loop`.

Eso es la mitad del planner que no cuesta un canal. La checklist es un tipo de
dato con su intérprete y vive en `core.plan`; el cableado es un patrón y vive acá.
La línea entre las dos mitades es la respuesta a si un plan es un primitivo: la
parte que compone, no.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence

from catalejo.core import Cell, loop, then
from catalejo.llm import Model

from .cells import Speech, Handle, executor, grounded, worker
from .repl import Environment

MAX_STEPS = 12


def drive(
    model: Model,
    handle: Handle,
    env: Environment,
    *,
    keep_recent: int = 6,
    keep_first: int = 1,
    max_steps: int = MAX_STEPS,
    budget: int | None = None,
    deadline: float | None = None,
    extras: Sequence[Cell] = (),
    speech: Speech | None = None,
    wrap: Callable[[Cell], Cell] | None = None,
) -> Cell:
    """Un paso es proponer, ejecutar y revisar; el turno es repetir eso hasta el tope.

    `model` es el que propone el código de cada paso. Ve el preámbulo y la
    transcripción recortada, nunca el payload, así que puede ser uno barato.

    `handle` es lo que el modelo sabe del contexto: el nombre de la variable, el
    tamaño, el esquema y las herramientas. Si el `env` viene de `recurse`, sus
    `tools` tienen que ser los del workspace, o el modelo no se entera de que
    tiene `llm`.

    `env` es donde corre el código que el modelo propone: un `Workspace` pelado o
    uno de `recurse`. Su `var` y el de `handle` tienen que coincidir, porque el
    aviso de `grounded` y el preámbulo nombran el mismo.

    `keep_recent` es cuántos mensajes de la cola ve el modelo además de la
    cabeza, que se conserva siempre porque es la pregunta. `keep_first` es cuántos
    mensajes tiene esa cabeza: uno, salvo que el contrato de la célula venga en
    un mensaje aparte (ver `window`). Los aplica `window`; `keep_recent=0` es sin
    recorte.

    `max_steps`, `budget` y `deadline` son los tres topes del `loop`: pasos,
    tokens y segundos del turno entero. `None` en los dos últimos deja solo el
    de pasos. El `budget` de `recurse` es otro, el del árbol de delegaciones, y
    los dos conviven. `deadline` es el único que corta un paso a la mitad, y es
    el tope total que un host le pone a un turno: lo que los pasos anteriores
    acumularon sale igual (ver `loop`).

    El orden no es negociable en las tres primeras. `executor` va después del
    worker porque corre lo que el worker acaba de proponer, y `grounded` va después
    del executor porque mira `reads`, que el executor acaba de subir, y porque
    comparte con él `extract_code`.

    `extras` van al final por lo mismo: una célula que juzgue el paso necesita ver
    el paso entero, y en `then` cada célula ve lo que llegó más lo que agregaron
    las anteriores. El planner NO va acá: va alrededor de este loop, en
    `planned`, porque juzga el trabajo entero y no un paso.

    `speech` va directo al `executor`: es la forma de bloque que el host reconoce
    como prosa (ver `Speech`). Sin ella, todo bloque es código.

    `wrap` envuelve al `executor` y a nadie más: recibe la célula y devuelve la
    que va en su lugar. Es la costura para achicar lo que el executor acaba de
    agregar, que una célula puesta después no puede hacer porque solo agrega
    (la poda de secciones del asesor agro entra por acá).
    """
    run = executor(env, speech=speech)
    step = then(
        worker(model, handle, keep_recent=keep_recent, keep_first=keep_first),
        wrap(run) if wrap is not None else run,
        grounded(handle.var),
        *extras,
    )
    return loop(step, max_steps=max_steps, budget=budget, deadline=deadline)
