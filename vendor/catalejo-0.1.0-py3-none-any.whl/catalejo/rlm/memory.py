"""La memoria del contacto, navegable: la vista, `zoom`, `date` y el buscador que la recorre.

El dato vive en `core/memory.py` y llega en el canal `memory`, sembrado por el host. Este
módulo es lo que cualquier agente necesita para usarlo, para que un vertical nuevo cablee
`memory_search` en su `orchestrate` en vez de rehacer las herramientas cliente por cliente.
Sigue la spec de OptChat (gist de Victor Taelin, 91837951a5ce5b38f341ec1ba1df6449); los §
de abajo son los de ella.

# La forma

    orchestrate([buscador, only(has_memory, memory_search(model, prompt))], redactora, ...)
    memory_search = boundary(then(say(prompt), drive(model, handle, ws)),
                             drop("reads") ∘ report("memoria", ()))

Corre en `fanout` con el buscador del corpus porque contesta otra pregunta: qué sabemos de
este cliente. Sin memoria sembrada, `has_memory` (un hecho del Log) no la deja correr y no
cuesta nada. Con memoria cuesta un `drive` más por turno, en paralelo: suma costo, no
latencia.

# Qué ve el modelo

La vista en el preámbulo (`Handle.schema`) y el log entero en la variable `memoria` del
REPL. La vista es el mapa: un resumen de toda la historia que siempre pesa lo mismo, lo viejo
grueso y lo reciente fino, y cada línea dice qué tramo cubre (`0+16`). `zoom` abre una línea
en sus dos mitades, hasta el mensaje entero; `date` da la fecha de un mensaje; el `grep` de
siempre busca en el log. Las herramientas entran por `extra=` del REPL de ESTA célula: el del
catálogo no las tiene, así que un buscador que las llamara recibiría un `NameError`, no algo
que dependa de que su prompt no las nombre. Por eso viven acá y no en el REPL oficial.

# Qué cruza el borde

Un `Report` firmado `memoria`, sin fuentes: `render_reports` abre cada fuente con el
`document` del corpus, y un `0+16` no es una ruta del catálogo. Los ids van en la prosa.
`reads` NO cruza (`drop("reads")`, como la redactora): el canal dice que alguien consultó el
corpus, y la compuerta que cierra "buscar" no puede creer que leer la memoria es eso. Que la
memoria sí se consultó lo dice `Report.is_grounded`, que `report` calcula antes del `drop`.

# La vista (§5.2)

Se pliega desde el mensaje 0: cada mensaje se agrega al final como parte de nivel 0 y,
mientras el total pase el presupuesto, se une el par adyacente más vencido cuyo padre esté
armado, `due = (T - start) / 2^(l+2)`. Nunca se parte. Desvío: si no queda ningún padre
armado, se une igual y el padre sale `UNBUILT`, para que la vista no pase nunca del
presupuesto mientras el árbol se compacta (ver `view`). No se guarda ni viaja: se calcula del
árbol en cada turno, como el plan de sus movidas. Un nodo sin armar se muestra como
`UNBUILT` (§6: nunca texto cortado).

Desvío de la spec, con motivo: cada línea lleva el rango de fechas que cubre. La spec las saca
por los bytes y por el caché de prompts entre turnos; acá la vista es chica y el agente no
cachea entre turnos, y para un cliente que compra por temporada la fecha es lo que dice
cuándo toca recomprar.

# Los nodos gratis (§3)

Un mensaje corto es su propio nodo de nivel 0 (`kind: texto`), y dos hijos que juntos caben
en `NODE` son el padre. El host puede mandarlos o no: si faltan, se calculan acá igual.

Desde el 5 de octubre de 2026, sin medir.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from functools import partial

from catalejo.core import Cell, Entry, Log, Memory, Message, Node, Role, Rule, boundary, drop, then
from catalejo.llm import Model

from .cells import Handle, report
from .drive import drive
from .repl import Container, Repl, Workspace

NODE = 512
"""Bytes de una línea del árbol (§3). 280 era el de OptMem; con 128 los resúmenes no servían."""

VIEW = 8_000
"""Bytes de la vista. La spec usa 128.000 para un agente de código; un cliente es mucho menos."""

UNBUILT = "(not summarized yet: open it with zoom)"
NO_DATE = "no date"
MEMORY_STEPS = 6
MEMORY_TOKENS = 40_000
"""Tokens de un turno del buscador de la memoria, sumando sus pasos. Con la vista en su
presupuesto un paso son unos 5k: alcanza para los seis. Es el techo por si algo vuelve a
crecer: el 6 oct 2026 una vista sin acotar hizo ~480k por turno. El `loop` lo mira después
de cada paso, así que se puede pasar por uno."""
WHO = "memory"
VAR = "memory"

SCHEMA = (
    "the log of this customer's history with the business, from earlier conversations: one "
    "message per line, `i|date|who: text`, from oldest to newest. It is summarized by this "
    "view, where each line is `start+count|dates|summary` and covers that count of "
    "messages from `start`; older content is more summarized and recent content more detailed, "
    "and the newest prevails:\n\n{view}"
)

NOTE = (
    "For the memory you also have `zoom(start, count)`, which opens a line of the view "
    "into the two lines, each with half the messages, it came from; `zoom(i, 1)` gives message "
    "`i` whole. And `date(i)`, the date and time of message `i`. Open a line when what you "
    "need is only named in the summary, before assuming."
)


def _bytes(text: str) -> int:
    return len(text.encode("utf-8"))


def _flat(text: str) -> str:
    return " ".join(text.split())


def _split(memory: Memory) -> tuple[dict[int, Entry], dict[tuple[int, int], str]]:
    """Los mensajes por `i` y los nodos por `(l, i)`. Un nodo repetido se queda con el primero del orden canónico."""
    entries: dict[int, Entry] = {}
    nodes: dict[tuple[int, int], str] = {}
    for item in memory:
        if isinstance(item, Entry):
            entries.setdefault(item.i, item)
        else:
            nodes.setdefault((item.l, item.i), item.text)
    return entries, nodes


def size(memory: Memory) -> int:
    """Cuántos mensajes cubre la memoria: `T` en la spec."""
    entries, nodes = _split(memory)
    ends = [i + 1 for i in entries] + [(i + 1) * 2**l for l, i in nodes]
    return max(ends, default=0)


def _line(entries: dict[int, Entry], nodes: dict[tuple[int, int], str], l: int, i: int) -> str | None:  # noqa: E741
    """El texto del nodo `(l, i)`: el que mandó el host, o el gratis, o `None` si no está armado."""
    if (l, i) in nodes:
        return nodes[(l, i)]
    if l == 0:
        e = entries.get(i)
        if e is not None and _bytes(f"{e.kind}: {e.text}") <= NODE:
            return f"{e.kind}: {e.text}"
        return None
    a = _line(entries, nodes, l - 1, 2 * i)
    b = _line(entries, nodes, l - 1, 2 * i + 1)
    if a is not None and b is not None and _bytes(f"{a}\n{b}") <= NODE:
        return f"{a}\n{b}"
    return None


def _dates(entries: dict[int, Entry], start: int, n: int) -> str:
    days = [entries[k].date[:10] for k in range(start, start + n) if k in entries and entries[k].date]
    if not days:
        return NO_DATE
    return days[0] if days[0] == days[-1] else f"{days[0]}..{days[-1]}"


def _render(entries: dict[int, Entry], nodes: dict[tuple[int, int], str], l: int, i: int) -> str:  # noqa: E741
    n = 2**l
    text = _line(entries, nodes, l, i)
    return f"{i * n}+{n}|{_dates(entries, i * n, n)}|{_flat(text) if text is not None else UNBUILT}"


def _due_pair(
    entries: dict[int, Entry], nodes: dict[tuple[int, int], str], parts: list[tuple[int, int]], t: int, built: bool
) -> int | None:
    """El par adyacente más vencido, `due = (T - start) / 2^(l+2)`; con `built`, solo uno cuyo padre esté armado."""
    best, due = None, -1.0
    for k in range(len(parts) - 1):
        (la, ia), (lb, ib) = parts[k], parts[k + 1]
        if la != lb or ia % 2 or ib != ia + 1:
            continue
        if built and _line(entries, nodes, la + 1, ia // 2) is None:
            continue
        d = (t + 1 - ia * 2**la) / 2 ** (la + 2)
        if d > due:
            best, due = k, d
    return best


def view(memory: Memory, budget: int = VIEW, *, bounded: bool = True) -> tuple[tuple[int, int], ...]:
    """Las partes `(l, i)` que cubren toda la memoria dentro del presupuesto, de la más vieja a la más nueva (§5.2).

    Une primero un par cuyo padre esté armado. Si no queda ninguno (un árbol que todavía no
    se compactó) y la vista sigue pasada, `bounded` une igual el par más vencido: el padre se
    muestra `UNBUILT` y se abre con `zoom`. Sin eso, un contacto con 3.211 mensajes y el árbol
    a medio armar dio una vista de 328 KB que el buscador reenviaba en cada paso (6 oct 2026).
    `bounded=False` es el pliegue de la spec tal cual, el que necesita el compactador para
    saber cuál es la primera línea sin armar.
    """
    entries, nodes = _split(memory)
    parts: list[tuple[int, int]] = []
    weight: list[int] = []
    for t in range(size(memory)):
        parts.append((0, t))
        weight.append(_bytes(_render(entries, nodes, 0, t)))
        while sum(weight) > budget:
            best = _due_pair(entries, nodes, parts, t, built=True)
            if best is None and bounded:
                best = _due_pair(entries, nodes, parts, t, built=False)
            if best is None:
                break
            l, i = parts[best]
            parts[best : best + 2] = [(l + 1, i // 2)]
            weight[best : best + 2] = [_bytes(_render(entries, nodes, l + 1, i // 2))]
    return tuple(parts)


def render_view(memory: Memory, budget: int = VIEW) -> str:
    """La vista como la lee el modelo: una línea `inicio+cantidad|fechas|resumen` por parte."""
    entries, nodes = _split(memory)
    return "\n".join(_render(entries, nodes, l, i) for l, i in view(memory, budget))


def log_text(memory: Memory) -> str:
    """El log como texto para `grep`: un mensaje por línea, `i|fecha|quien: texto`."""
    entries, _ = _split(memory)
    return "\n".join(
        f"{e.i}|{e.date[:10] or NO_DATE}|{e.kind}: {_flat(e.text)}" for e in sorted(entries.values(), key=lambda e: e.i)
    )


def zoom(memory: Memory, start: int, count: int) -> str:
    """Abre la línea `start+n` en sus dos mitades; con `n == 1`, el mensaje entero (§7.1)."""
    total = size(memory)
    if count < 1 or count & (count - 1):
        return f"`count` must be a power of 2 (1, 2, 4, 8…); got {count}. Copy the `start+count` from a line of the view."
    if start % count:
        return f"There is no line {start}+{count}: `start` must be a multiple of {count}. Copy the `start+count` from a line of the view."
    if start < 0 or start + count > total:
        return f"There is no line {start}+{count}: the memory has {total} messages, from 0 to {total - 1}."
    entries, nodes = _split(memory)
    if count == 1:
        e = entries.get(start)
        if e is not None:
            return f"{start}+1|{e.date or NO_DATE}|{e.kind}: {e.text}"
        text = _line(entries, nodes, 0, start)
        if text is not None:
            return f"{start}+1|{NO_DATE}|{_flat(text)}\n(the whole message did not come in the memory; this is its summary)"
        return f"Message {start} did not come in the memory and has no summary."
    l = count.bit_length() - 2  # noqa: E741 — el nivel de las dos mitades
    i = start // (count // 2)
    return "\n".join(_render(entries, nodes, l, k) for k in (i, i + 1))


def date(memory: Memory, i: int) -> str:
    """La fecha y hora del mensaje `i`, ISO 8601."""
    entries, _ = _split(memory)
    e = entries.get(i)
    if e is None:
        return f"Message {i} did not come in the memory (there are {size(memory)}, from 0 to {size(memory) - 1})."
    return e.date or f"Message {i} has no date."


def _workshop(payload: str, extra: dict[str, Callable[..., str]], contained: bool) -> Repl:
    """El REPL de la memoria, recién armado: el log en `memoria`, y `zoom` y `date`."""
    if contained:
        return Container(payload, var=VAR, extra=extra, note=NOTE, two_step=False)
    return Workspace(payload, var=VAR, extra=extra, note=NOTE, two_step=False)


def has_memory(seen: Log) -> bool:
    """El host sembró memoria. Un hecho del Log: el canal no está vacío."""
    return bool(seen.memory)


def memory_search(
    model: Model,
    prompt: str,
    *,
    who: str = WHO,
    budget: int = VIEW,
    max_steps: int = MEMORY_STEPS,
    max_tokens: int | None = MEMORY_TOKENS,
    deadline: float | None = None,
    keep: Rule | None = None,
    contained: bool = False,
) -> Cell:
    """El buscador de la memoria: un `drive` sobre el log con `zoom` y `date`, que sale como un `Report` sin `reads`.

    `prompt` es el contrato del papel y es del host: qué tiene que traer de la memoria para
    este negocio. `max_tokens` es el techo del turno (`MEMORY_TOKENS`). `keep` es la regla del `Dossier` que guarda la transcripción, si el host la
    quiere. `contained` corre el REPL en un proceso hijo; `zoom` y `date` se quedan en el
    padre, como todo builtin que es función (ver `Container`).
    """
    collapse = report(who, ())
    hush = drop("reads")
    said = Message(Role.USER, prompt)

    async def cell(seen: Log) -> Log:
        memory = seen.memory
        payload = log_text(memory)
        extra: dict[str, Callable[..., str]] = {"zoom": partial(zoom, memory), "date": partial(date, memory)}
        ws: Repl = await asyncio.to_thread(_workshop, payload, extra, contained)
        try:
            handle = Handle(
                var=ws.var,
                schema=SCHEMA.format(view=render_view(memory, budget)),
                size=f"{size(memory)} messages",
                tools=ws.tools,
            )

            async def say(seen: Log) -> Log:
                return Log(said=(said,))

            # `keep_first=2`: la pregunta del turno y el contrato, que el recorte de la cola no toca.
            work = then(say, drive(model, handle, ws, keep_first=2, max_steps=max_steps, budget=max_tokens, deadline=deadline))

            def rule(log: Log) -> Log:
                return hush(collapse(keep(log) if keep else log))

            return await boundary(work, rule)(seen)
        finally:
            await asyncio.to_thread(ws.close)

    return cell
