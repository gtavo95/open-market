"""Las células del plan, y el planner que las compone como `drive` compone las del paso.

Tres células, tres actos: `seed` siembra el plan si el canal está vacío, `close_steps`
cierra por juicio lo que el juez dice que ya pasó, y `steer` mira lo que queda y
habla: si falta algo, le dice al modelo qué (`voice`) y vota CONTINUE; si no
falta nada, vota DONE. `planner` es `then(seed, close_steps, steer)`, y sin `voice`
es `then(seed, close_steps)`: un plan que se siembra y se cierra pero no manda, como
la venta de `agro`, que dura la conversación y al final de un turno puede quedar
abierta sin que eso sea un problema.

Son las mismas células para los dos canales; lo que cambia es de cuál proyectan
y a cuál emiten. Ninguna le habla al modelo salvo `steer`, y ninguna vota salvo
`steer`. El modelo no mueve el plan: lo siembra el host y lo cierra el juez, y
un paso sin compuerta no lo cierra nadie. Por eso cada paso de un plan que va a
`steer` necesita su `done_when`: uno sin compuerta queda abierto hasta que
se acaben las vueltas.

Dónde va el planner en el turno lo dice `rlm/planned.py`: antes del trabajo, para
que el modelo sepa qué hacer, y después, para juzgar lo que hizo.

Hasta el 20 de septiembre de 2026 el planner iba ADENTRO del paso, como `extras`
de `drive`, con el modelo proponiendo ops desde el REPL y un veto sobre la prosa.
Está en el historial antes de `f1b1ce6`, con el porqué de cada pieza.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from typing import Any, Literal

from catalejo.core import (
    CLOSED,
    ZERO,
    Cell,
    Fail,
    Judge,
    Log,
    Message,
    Plan,
    PlanOp,
    Predicate,
    Role,
    Status,
    Step,
    children,
    close_by_gate,
    closed,
    pending,
    project,
    then,
)

type PlanChannel = Literal["steps", "course"]
"""Los dos canales de movidas: el del turno y el de la conversación."""

type Voice = Callable[[Plan], str]
"""Lo que el planner le dice al modelo cuando el plan sigue abierto.

Es del host, como el juez: qué ES la respuesta en ese momento lo sabe quien armó
el agente, no la librería. `checklist` es la de fábrica, para empezar.
"""

STATE = "[plan] state:"

MARKS = {"todo": "[ ]", "active": "[>]", "done": "[x]", "skipped": "[-]"}


def ops_of(seen: Log, channel: PlanChannel) -> tuple[PlanOp, ...]:
    """Las movidas de ese canal."""
    ops: tuple[PlanOp, ...] = getattr(seen, channel)
    return ops


def with_ops(log: Log, channel: PlanChannel, ops: tuple[PlanOp, ...]) -> Log:
    """El mismo Log con esas movidas en ese canal."""
    changes: dict[str, Any] = {channel: ops}
    return replace(log, **changes)


def unfinished(channel: PlanChannel = "steps") -> Predicate:
    """Si el plan de ese canal tiene pasos abiertos. Es la compuerta del trabajo en `planned`."""
    return lambda seen: bool(pending(project(ops_of(seen, channel))))


def checklist(plan: Plan) -> str:
    """La voz de fábrica: el plan dibujado, con las etapas sangradas, y qué falta.

    Una etapa cerrada por sus hijos se dibuja `[x]` aunque su estado diga `todo`:
    lo que se dibuja es lo que `closed` calcula, no el campo.
    """

    def line(s: Step, indent: str) -> str:
        done = closed(plan, s)
        mark = MARKS["done"] if done and s.status not in CLOSED else MARKS.get(s.status, "[?]")
        return f"{indent}{mark} {s.id}" + (f": {s.intent}" if s.intent else "")

    def branch(padre: str, indent: str) -> list[str]:
        return [x for s in children(plan, padre) for x in [line(s, indent), *branch(s.id, indent + "    ")]]

    left = ", ".join(f"`{s.id}`" for s in pending(plan) if not children(plan, s.id))
    return "\n".join([STATE, *branch("", ""), f"Remaining: {left}."])


def seed(ops: tuple[PlanOp, ...], *, channel: PlanChannel = "steps") -> Cell:
    """Siembra el plan en el canal si está vacío; si ya tiene historia, no agrega nada.

    Un canal que el host sembró desde afuera no está vacío, y la semilla no se
    vuelve a emitir: así el plan de la conversación entra con su historia en
    cada turno, y correr esta célula dos veces en el mismo turno es gratis.
    """

    async def cell(seen: Log) -> Log:
        return ZERO if ops_of(seen, channel) else with_ops(ZERO, channel, ops)

    return cell


def close_steps(judge: Judge, *, channel: PlanChannel = "steps", umbral: float = 0.8) -> Cell:
    """Cierra por juicio los pasos abiertos de un plan. Una llamada al juez por corrida.

    Pliega el canal, junta los `done_when` de los pasos que siguen abiertos,
    se los pregunta al juez todos juntos, y emite un `mark(done)` por cada uno
    que llegue a `umbral`. Lo cierra esta célula, nunca el modelo. Pregunta solo
    por lo abierto: con `plaga` cerrada no vuelve a preguntar por `plaga`.

    `umbral` es desde qué probabilidad un sí es un sí. Un juez de predicados
    (`facts`) contesta 0 o 1 y cualquier umbral le sirve; el del host, calibrado,
    trae el suyo. Las probabilidades no van al Log: `PlanOp` no las lleva y el
    plegado no las necesita. El juez del host las guarda si el eval las quiere.

    Un nombre que el juez no contesta es un `Fail` en cada corrida, y ese paso no
    se cierra nunca: al revés, una compuerta mal escrita desactivaría el
    requisito y nadie se enteraría. Un juez que levanta es un `Fail` y nada se
    cierra en esa corrida. Las dos veces el lado seguro es seguir pidiendo.

    Va después de `seed` en el mismo `then`, así proyecta el plan que `seed`
    acaba de sembrar. No vota nunca.
    """

    async def cell(seen: Log) -> Log:
        plan = project(ops_of(seen, channel))
        open_steps = [s for s in pending(plan) if s.done_when]
        if not open_steps:
            return ZERO
        names = frozenset(s.done_when for s in open_steps)
        try:
            answers = await judge(seen, names)
        except Exception as e:
            return Log(fails=(Fail("plan", f"the judge blew up: {type(e).__name__}: {e}"),))
        ready = frozenset(n for n in names if answers.get(n, 0.0) >= umbral)
        failures = tuple(
            Fail("plan", f"nobody answers `{s.done_when}`, so `{s.id}` is never closed")
            for s in open_steps
            if s.done_when not in answers
        )
        return with_ops(Log(fails=failures), channel, close_by_gate(plan, ready))

    return cell


def steer(voice: Voice, *, channel: PlanChannel = "steps") -> Cell:
    """Mira qué queda y manda: con pasos abiertos dice qué falta y vota CONTINUE; sin nada abierto vota DONE.

    Es la única célula del plan que vota, y por eso un plan que va a `steer`
    tiene un solo terminador: el turno termina cuando el juez cerró todo, y
    mientras no, cada vuelta arranca con `voice(plan)` como turno del usuario.
    Sobre un plan vacío vota DONE sin decir nada: una checklist vacía no exige
    nada, y no hay a quién mandarle.

    Va después de `close_steps` en el mismo `then`, así proyecta el plan que `close_steps`
    acaba de cerrar: un cierre por juicio en esta corrida levanta el pedido en
    esta corrida.
    """

    async def cell(seen: Log) -> Log:
        plan = project(ops_of(seen, channel))
        if not pending(plan):
            return Log(vote=Status.DONE)
        return Log(said=(Message(Role.USER, voice(plan)),), vote=Status.CONTINUE)

    return cell


def planner(
    judge: Judge,
    *,
    seed_ops: tuple[PlanOp, ...] = (),
    channel: PlanChannel = "steps",
    umbral: float = 0.8,
    voice: Voice | None = None,
) -> Cell:
    """`then(seed, close_steps, steer)`, el planner de un canal. Sin `voice`, `then(seed, close_steps)`.

    El orden importa: `close_steps` proyecta el plan que `seed` acaba de sembrar, y
    `steer` el que `close_steps` acaba de cerrar, todo en la misma corrida. Al revés,
    el modelo se llevaría un pedido por un paso que ya estaba cerrado.

    `seed_ops` es la checklist con la que arranca el canal vacío; vacía, el plan
    entra sembrado por el host o no hay plan. `judge` contesta los
    `done_when` (ver `Judge`). `voice` es lo que le dice al modelo cuando
    falta algo; sin ella el planner no habla ni vota, que es lo que quiere un
    plan que dura más que el turno, como `course` en `agro`.
    """
    cells = [seed(seed_ops, channel=channel), close_steps(judge, channel=channel, umbral=umbral)]
    if voice is not None:
        cells.append(steer(voice, channel=channel))
    return then(*cells)
