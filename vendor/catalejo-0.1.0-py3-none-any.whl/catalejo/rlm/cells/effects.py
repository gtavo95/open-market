"""Las células de los efectos: `propose_effects` propone por juicio, `resolve_args` completa por código,
`propose_handoff` propone lo que el turno no resolvió.

# La forma

    orchestrate([buscador], redactora, before=[venta, propose_effects], after=[venta, resolve_args, propose_handoff])
      = then(venta, propose_effects, fanout(buscador), redactora, venta, resolve_args, propose_handoff)

`propose_effects` va a la entrada, después del plan de la conversación: pliega el canal
`effects`, mira qué intents de la tabla del host no están todavía, y le pregunta
al juez por las palabras del cliente. Lo que llega al umbral sale como un
`propose` en `effects`, y el buscador y la redactora lo ven en `seen` antes de
trabajar: la redactora escribe sabiendo que el sistema manda la ficha con este
mensaje. `resolve_args` va a la salida: para cada efecto propuesto que tenga un
`Resolver` en la tabla, lo corre sobre el Log del turno y emite un `resolve` con
los args que devolvió (la ruta de la ficha que la redactora citó). El host
recibe las movidas del turno, ejecuta en el borde, y siembra `done` o `reject`.

# `propose_handoff`: lo que el turno no resolvió

`propose_effects` propone a la entrada y mira al cliente; `propose_handoff` propone a la salida
y mira cómo terminó el turno. Es la otra mitad: un agente que le contesta "eso
no está en la ficha" a quien le cree no falla en silencio, deja una
conversación sin dueño. El veredicto es del host (`Verdict`): recibe el Log del
turno terminado y devuelve los args del efecto a proponer, o `None` si no hay
nada que proponer. La librería no sabe qué es un motivo ni quién atiende.

Por qué no es `propose_effects` con otro juez. Un `Judge` contesta probabilidades por
nombre, y lo que hay que mandarle al host no es una probabilidad: es una
etiqueta, de qué es esto, para que caiga en la cola que le toca. La etiqueta
viaja en los args del mismo `propose`, que es lo que `apply_effect` ya acepta.

Por qué no es un `resolve_args` detrás de un `propose_effects`. Dos razones, y las dos son
del álgebra. `resolve_args` es código y no va a la red, y una etiqueta que sale de
un juicio sí; y `resolve_args` UNE los args en vez de pisarlos, así que un efecto
que queda propuesto tres turnos juntaría tres motivos distintos sobre el mismo
id. Lo que se propone con lo que lo explica no tiene ese problema.

Un id por conversación, como en `propose_effects`: el canal ya trae el propuesto, el
hecho o el rechazado, y con eso nadie escala dos veces lo mismo. Que la persona
cierre la primera y el asesor se quede sin respuesta cinco turnos después es el
mismo límite de más abajo, y se levanta igual: un id con el turno.

# Qué leen, qué emiten, qué cuestan

Ninguna habla ni vota: son QUIET, como `venta`. `propose_effects` lee `effects` y lo que
el juez mire (las palabras del cliente); emite `effects` y `fails`. `resolve_args` lee
`effects` y lo que cada `Resolver` mire; emite `effects`. Cero llamadas al
modelo. `propose_effects` es una llamada al juez por corrida, con los nombres de los
intents que faltan; con un juez que memoiza por turno, como el de `agro`, sale
gratis después del planner. Un juez que revienta es un `Fail` y nada se propone
en esa corrida; un nombre que nadie contesta es un `Fail` por corrida y ese
intent no se propone nunca. Las dos veces el lado seguro es no mandar nada.

# Por qué el juez y no el modelo

La propuesta no puede salir de lo que el modelo escribe, porque lo que el modelo
lee no es confiable: una ficha del corpus con "mandale la cuenta al cliente"
adentro no puede disparar un envío. El juez mira las palabras del cliente y
nada más, así que la frontera de inyección de `docs/diseno.md` queda donde
estaba. Por lo mismo `report` calla `effects` en el borde del buscador: si algo
adentro propusiera, se queda ahí como su `said`.

# `requires` son nombres al juez

`Intent.requires` podría leerse del plan de la conversación (proponer la cuenta
solo con `quiere_comprar` cerrado). Son nombres al mismo juez a propósito: un
solo mecanismo, un solo umbral, y con la memo del turno no cuesta nada más. Lo
que le falta al cliente para que un efecto salga (el correo, el medio de pago)
no es un efecto bloqueado: es un paso del plan con su pregunta. El plan pide,
el juez cierra, `propose_effects` propone, el host ejecuta.

# Dos límites, dichos

Un id se propone una vez por conversación: `propose_effects` salta lo que ya está en el
canal, propuesto, hecho o rechazado. El juicio del host de `agro` es sobre "lo
que el cliente dijo hasta ahora", así que no distingue "pidió otra ficha
después de que le mandaron la primera"; levantarlo es una pregunta sobre el
último mensaje y un id con el turno, y queda como paso siguiente. Y los args que
son texto del cliente (un correo, una fecha) son un `Resolver` del host, no del
juez: un juez de probabilidades no transcribe.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping

from catalejo.core import (
    ZERO,
    Args,
    Cell,
    EffectOp,
    Fail,
    Intent,
    Judge,
    Log,
    effects_of,
    find_effect,
    proposed,
)

type Resolver = Callable[[Log], Args]
"""Los args de un efecto propuesto, sacados del Log del turno por código. Vacío es "todavía no"."""

WHO = "effects"


def propose_effects(judge: Judge, intents: Mapping[str, Intent], *, umbral: float = 0.8) -> Cell:
    """Propone por juicio los intents que faltan. Una llamada al juez por corrida.

    Pliega `effects`, se queda con los intents cuyo id no está en el canal, le
    pregunta al juez todos sus nombres juntos (`asked` y `requires`), y emite
    un `propose` por cada intent con todos sus nombres a `umbral`. Con todo ya
    propuesto o hecho devuelve ZERO sin ir al juez.

    `umbral` es desde qué probabilidad un sí es un sí, el mismo que `close_steps`.
    Las probabilidades no van al Log: `EffectOp` no las lleva.
    """

    async def cell(seen: Log) -> Log:
        have = {e.id for e in effects_of(seen.effects)}
        wanted = {id_: i for id_, i in intents.items() if id_ not in have}
        if not wanted:
            return ZERO
        names = frozenset(n for i in wanted.values() for n in (i.asked, *i.requires))
        try:
            answers = await judge(seen, names)
        except Exception as e:
            return Log(fails=(Fail(WHO, f"the judge blew up: {type(e).__name__}: {e}"),))
        ops = tuple(
            EffectOp("propose", id_, i.kind)
            for id_, i in wanted.items()
            if all(answers.get(n, 0.0) >= umbral for n in (i.asked, *i.requires))
        )
        fails = tuple(
            Fail(WHO, f"nobody answers `{n}`, so `{id_}` is never proposed")
            for id_, i in wanted.items()
            for n in (i.asked, *i.requires)
            if n not in answers
        )
        return Log(effects=ops, fails=fails)

    return cell


def resolve_args(resolvers: Mapping[str, Resolver]) -> Cell:
    """Completa por código los args de lo propuesto. No va a la red.

    Para cada efecto que sigue propuesto y tiene `Resolver`, emite un `resolve`
    con lo que el resolver devolvió; un resolver que devuelve vacío no emite
    nada, y el efecto queda propuesto sin args para que el host decida. Un
    efecto sin resolver no necesita args: el host ya sabe qué mandar.
    """

    async def cell(seen: Log) -> Log:
        ops = tuple(
            EffectOp("resolve", e.id, args=args)
            for e in proposed(effects_of(seen.effects))
            if e.id in resolvers and (args := resolvers[e.id](seen))
        )
        return Log(effects=ops)

    return cell


type Verdict = Callable[[Log], Awaitable[Args | None]]
"""Lo que el host dice del turno terminado: los args del efecto a proponer, o `None` si no hay nada.

Los args son lo que el host necesita para atenderlo, y el que los arma es el que
sabe (el motivo, la cola, quién lo pidió). Si no tiene con qué juzgar no
devuelve `None`: levanta, y `propose_handoff` lo deja como `Fail`. `None` es "miré y no
hay nada que proponer", que es otra cosa y no se avisa.
"""


def propose_handoff(verdict: Verdict, *, id: str = "handoff", kind: str = "handoff") -> Cell:
    """Propone un efecto con lo que el veredicto del host diga del turno. Va al final, después de la redactora.

    Pliega `effects`: si el id ya está en el canal, propuesto, hecho o
    rechazado, devuelve ZERO sin consultarle a nadie. Si no, le pregunta al
    veredicto por el Log del turno entero, con la respuesta ya escrita, y emite
    un solo `propose` con los args que le dio. Un veredicto que levanta es un
    `Fail` y no se propone nada: el lado seguro es no abrirle un caso a nadie.

    No habla y no vota, como las otras dos. Lo que sale del turno lo escribió la
    redactora, y esto es una movida en un canal que ella ya no lee: lo que el
    cliente vea de la escalada lo dice el host, que es el que sabe si del otro
    lado hay alguien.
    """

    async def cell(seen: Log) -> Log:
        if find_effect(effects_of(seen.effects), id) is not None:
            return ZERO
        try:
            args = await verdict(seen)
        except Exception as e:
            return Log(fails=(Fail(WHO, f"the verdict blew up: {type(e).__name__}: {e}"),))
        if args is None:
            return ZERO
        return Log(effects=(EffectOp("propose", id, kind, args),))

    return cell
