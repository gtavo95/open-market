"""La cita contra el conjunto cerrado: las rutas que la respuesta declara tienen que existir.

# El agujero que `grounded` no tapa

`grounded` mira `reads`: si el REPL devolvió algo alguna vez. Es un piso y no una
prueba, y el docstring lo dice: atrapa "contestó sin mirar" y no atrapa una cita
inventada sobre un texto que sí leyó. Pasó de verdad: preguntando por zompopo, una
plaga que el catálogo no cubre, el modelo consultó el catálogo, no encontró nada,
y cerró con tres `FUENTE: productos/...md` que no existen (beaveria-90,
isaria-forte, metarhizium-50). `grounded` lo dejó pasar, porque había leído.

Eso NO necesita un juez. Una cita es una afirmación sobre un conjunto conocido, y
eso se verifica con código, exacto y gratis. `phantoms` ya lo hacía en
`evals.py`, o sea después de la corrida y sin frenar nada. Acá hace lo mismo
durante el turno.

# De dónde sale el conjunto

De las cabeceras `=== ruta ===` del texto que se le dio al modelo, con `paths`,
que vive en `repl/workspace.py` al lado de `HEADER` porque es conocimiento del
formato del corpus, no de la respuesta. Se calcula en el padre ANTES de armar el
Environment. Tiene que ser así porque
la célula corre en el padre y el corpus vive en el workspace, que con el
`Container` está en otro proceso. Y sale del texto y no de un segundo recorrido
del disco: una cita a un archivo que existe en el bundle pero no en el corpus es
tan inventada como una a un archivo que no existe en ninguna parte.

# Un solo parser

`citations` e `phantoms` viven acá y `evals.py` las importa. Es la regla que ya
rige entre `grounded` y `executor` con `extract_code`: dos células que parsean lo
mismo con su propio código se desincronizan, dos que llaman a la misma función
no. Lo que se parsea acá es la RESPUESTA, las líneas `FUENTE:`; lo que se parsea
en el REPL es el corpus.

Compara sin acentos ni mayúsculas. Los archivos del bundle son slugs en
minúscula, pero el modelo escribe `Fungiban.md` a veces, y un error de mayúscula
no es una ficha inventada. Cambia el scorer del eval en la misma dirección.

# Misma forma que `grounded`, otro hecho

Avisa una vez votando CONTINUE, con las rutas que no existen y de dónde salen las
de verdad. Si el modelo insiste, lo deja salir con un `Fail`: la respuesta sale,
pero etiquetada. El aviso lista rutas, así que no es un mensaje fijo y "ya
avisé" se detecta por el prefijo `[cita]`, no por igualdad.

Lo que NO mira: la prosa. Una respuesta que recomienda un producto para una
plaga que la ontología no tiene, sin citar nada, pasa. Eso no es un chequeo de
cadenas; lo chequeable es darle la ontología como dato, y va aparte.
"""

from __future__ import annotations

from collections.abc import Collection

from catalejo.core import ZERO, Cell, Fail, Log, Message, Role, Status

from ..repl import strip_accents
from .executor import extract_code

PREFIX = "[citation]"

NOTICE = (
    "{prefix} You cited {paths}, and {missing} in `{var}`. The real paths are the ones on the "
    "`=== path ===` lines: find the datasheet with grep({var}, pattern) and cite only the "
    "files you read the fact from, or close with `SOURCE: none`."
)


def citations(text: str) -> tuple[str, ...]:
    """Todas las rutas que la respuesta declara como fuente.

    Todas y no la última, porque el CONTRATO de `agro.py` pide una línea
    `FUENTE:` por cada archivo del que salió un dato. Mirando solo la última, una
    ruta fabricada en la primera pasaba sin que nadie la viera.
    """
    return tuple(
        line.split(":", 1)[1].strip().strip("`").lstrip("/")
        for line in text.splitlines()
        if line.strip().upper().startswith("SOURCE:")
    )


def _key(path: str) -> str:
    return strip_accents(path).lower()


def phantoms(text: str, real: Collection[str]) -> tuple[str, ...]:
    """Las rutas citadas que no existen, si las hay. `ninguna` no es una ruta."""
    keys = {_key(r) for r in real}
    return tuple(
        r
        for r in citations(text)
        if r and r.lower() != "none" and _key(r) not in keys
    )


def existing(text: str, real: Collection[str]) -> tuple[str, ...]:
    """Las rutas citadas que sí existen, escritas como las escribe el corpus.

    Es el complemento de `phantoms` y comparte su plegado, así que `Fungiban.md`
    casa con `productos/fungiban.md` y sale canónica, lista para abrir el
    documento con `read`. Sin repetidas y en el orden en que se citaron. Es lo
    que un `Report` lleva en `sources`: el que redacta abre estas rutas, y una
    ruta con la mayúscula del modelo no abriría nada.
    """
    canonical = {_key(r): r for r in real}
    seen_ones: list[str] = []
    for r in citations(text):
        hit = canonical.get(_key(r))
        if hit is not None and hit not in seen_ones:
            seen_ones.append(hit)
    return tuple(seen_ones)


def render_notice(ghosts: tuple[str, ...], var: str, template: str = NOTICE) -> str:
    listing = ", ".join(f"`{r}`" for r in ghosts)
    missing = "it does not exist" if len(ghosts) == 1 else "none of them exists"
    return template.format(prefix=PREFIX, paths=listing, missing=missing, var=var)


def cited(real: Collection[str], var: str = "ctx", *, notice: str = NOTICE) -> Cell:
    """Vota CONTINUE cuando la respuesta cita una ruta que no está en `real`.

    Va después del executor, como `grounded`, y solo opina sobre prosa: un
    mensaje con código no es una respuesta. `real` son las rutas del corpus,
    de `paths(texto)`.

    `notice` es la plantilla del aviso, con `{prefijo}`, `{rutas}`, `{falta}` y
    `{var}`. Tiene que empezar por `{prefijo}`, porque "ya avisé" se detecta por
    el prefijo `[cita]` y no por igualdad: el aviso lista rutas y cambia cada vez.
    """
    pool = frozenset(real)
    template = notice

    async def cell(seen: Log) -> Log:
        if not seen.said:
            return ZERO
        last = seen.said[-1]
        if last.role is not Role.ASSISTANT or extract_code(last.text):
            return ZERO
        ghosts = phantoms(last.text, pool)
        if not ghosts:
            return ZERO
        if any(m.role is Role.USER and m.text.startswith(PREFIX) for m in seen.said):
            return Log(fails=(Fail("citation", f"cited paths that do not exist: {', '.join(ghosts)}"),))
        return Log(said=(Message(Role.USER, render_notice(ghosts, var, template)),), vote=Status.CONTINUE)

    return cell
