"""El borde de un buscador: lo que dijo se vuelve un informe firmado, y su transcripción queda en el expediente.

# Qué problema resuelve

Dos células compuestas que hablan en el mismo Log se mezclan: `said` es una sola
lista y un `Message` no dice quién lo dijo. Hasta acá el repo lo resolvía fuera
del tipo, en `recurse.answer`, que colapsa el Log de un sub-agente a un `str` y lo
devuelve como salida del REPL. Sirve para `rlm()`, donde el que recibe es código.
No sirve cuando el que recibe es otra célula, porque un `str` no viaja por el Log.

Esto es lo mismo, adentro del álgebra. `report(quien, reales)` es una `Rule`
para `boundary`: toma lo que el buscador agregó, saca su última prosa, verifica
sus citas contra el corpus, y emite un `Report` en el canal `reports`. El
`said` del buscador no cruza, y no va escondido en ninguna otra parte del Log:
lo guarda el `Dossier`, afuera, para las capturas y para `--verbose`.

# Qué cruza y qué no

La regla es `drop("said", "vote", "steps", "effects")` más el informe, y en ese orden de
lectura: primero qué se calla, después qué se agrega. Lo que `drop` deja
pasar, pasa tal cual: `spent`, porque se pagó; `reads`, porque es la verdad
sobre si alguien consultó algo, y `grounded` en la célula que redacta lo
necesita; `course`, porque un buscador no lo mueve, y si alguna vez lo hiciera,
callarlo sería perder una movida de la venta; y los `reports` que el buscador
traiga de adentro, si él mismo orquesta a otros.

`fails` cruza firmado: `Fail("loop", ...)` sale como `Fail("catalogo/loop", ...)`.
Un fallo adentro del buscador no es el mismo hecho que ese fallo en el
orquestador, y con dos buscadores hay que saber de cuál fue. Los que deciden
por `who` (`evals.Corrida.perdida`, `agro.final`) miran `Fail.role_name`, el último
tramo, así que la firma no les cambia la lectura.

No cruzan `said`, `vote`, `steps` ni `effects`. El voto es lo que hace `then` seguro: un
buscador que se quedó sin pasos vota CONTINUE, y si eso saliera, el orquestador
lo heredaría sin que nadie lo haya pedido. `steps` es la checklist de SU turno,
que terminó. `effects` es una acción del host, y lo que un buscador lee es texto
del corpus, que no es confiable: desde el 21 de septiembre de 2026 solo el
orquestador propone efectos, y si algo adentro de un buscador lo hiciera, se
queda en su borde como su `said`. `said` no cruza de ninguna forma: hasta el 17 de septiembre de
2026 viajaba adentro del `Report`, "para el auditor", y eso era una segunda
pila de mensajes que ninguna célula leía pero cualquiera podía leer. Ahora
queda en el `Dossier`, que es la respuesta que el repo ya tenía para lo que el
borde tira y alguien igual necesita: medirlo en la fuente, como `Metered` con
el gasto de un sub-agente. Ver "El expediente" abajo.

# El expediente

`Dossier.keep(who)` es la otra regla del mismo borde: la identidad sobre el
Log, con el efecto de guardar `log.said` firmado en una lista del host. Va
antes de `report(...)`, sobre el mismo delta, así que guarda exactamente lo que
el buscador agregó y `report` después lo calla. El host lo vacía con `drain()`
al final de cada turno: `agro.answer` para imprimirlo con `--verbose` y
contar los mensajes, `evals` para la captura. Nada de esto está en el Log, y
por eso ninguna célula puede leerlo ni por accidente.

# La prosa

Es el último dicho que no es código, con `extract_code`, el único parser. Si lo
último que dijo es código, el buscador se quedó sin pasos a mitad de trabajo:
sale la última prosa si la hubo, o ese bloque, y abajo la marca de que se cortó
con sus `fails`, para que el que redacta no use media búsqueda como si fuera
entera. La marca la decide el último dicho y no los `fails`: con `planned`
alrededor del `drive`, una vuelta puede toparse y la siguiente cerrar con el
informe entero, y ahí el `Fail` del tope viaja igual por el canal, firmado,
pero el informe sale limpio. Hasta el 20 de septiembre de 2026 cualquier `Fail`
ponía la marca, y debajo de un informe entero decía que podía estar
incompleto. Es el mismo criterio que `recurse.answer`, con otro sustantivo; los
dos existen porque `recurse` importa `cells` y no al revés.

# Las fuentes

Tres escalones, y se baja uno solo cuando el de arriba no dice nada. Primero la
prosa: si cita, manda, y `FUENTE: ninguna` también es una cita. Después todo el
turno: es el tic que atiende `agro.impreso`, el buscador escribe sus `FUENTE:`
adentro de un `print`, el REPL se las devuelve, y en el paso siguiente las da por
dichas y escribe otra cosa. En el A/B del 16 de septiembre de 2026 pasó 2 de 3
veces en el turno del pago de un producto: las dos fichas leídas, las dos impresas,
y la prosa final sin ninguna. Y por último lo que LEYÓ entero: las cabeceras
`ruta: N líneas, de la a a la b.` que `read` deja en la salida del REPL, con
`repl.read_paths`, el mismo hecho que `agro.leyo` usa para la compuerta de la ficha.

El tercer escalón salió de complejos, la misma ronda: en tres turnos de pago el
buscador leyó `pagos.md` y `cuentas-bancarias.md`, le contestó al cliente en
prosa y no escribió ninguna `FUENTE:`, ni en prosa ni en un `print`. Con
`fuentes=()` la redactora contestó bien y cerró `FUENTE: ninguna`, que es lo que
el cierre le pide sin ficha abierta, y el caso perdió por la cita. Los 57
informes con fuentes acertaron; los 3 sin fuentes perdieron. Lo que el buscador
abrió entero lo tuvo delante, y eso alcanza para que la redactora lo reciba y lo
cite ella: el buscador es el `grep`, y si se olvidó de decir dónde, el host lo
vio pasar. Es un piso y no una prueba, igual que `leyo`; el costo es que
llegan también las fichas que abrió y descartó, y `existing` no las distingue.
El asomo de `one_per_step` no cuenta, porque ahí el modelo leyó otro documento
entero y a este solo lo vio pasar; la vista de `Workspace.peek` sí, porque ahí
es todo lo que `read` da y pedirla es abrir la ficha. La diferencia la lleva el
formato: `read_paths` toma la cabecera sola en su línea, y cada `read` la escribe
como corresponde.
"""

from __future__ import annotations

from collections.abc import Callable, Collection

from dataclasses import dataclass, replace

from catalejo.core import Conversation, Fail, Report, Log, Role, Rule, drop, merge

from ..repl import read_paths
from .citations import citations, existing
from .executor import extract_code

NO_PROSE = "(the searcher did not get to answer)"
CUT = "[the searcher was cut off: {reasons}. What is above may be incomplete.]"
UNGROUNDED = "(it consulted nothing: what it says comes from its memory, not from the corpus)"
SOURCES_BUDGET = 40_000
"""Bytes de fuentes abiertas en el pedido del que redacta, sumando todos los informes.

Una ficha de agro pesa 7 KB la mediana y 14 KB la más grande, y un turno cita de una a tres:
cuarenta entran de sobra en un turno normal. El tope es para el turno raro que cita diez,
que sin él mandaba setenta kilobytes al que redacta (desde el 7 de octubre de 2026)."""
UNOPENED = "(not opened: the request reached the cap of {budget} bytes of sources; do not recommend anything from it)"


def prose(log: Log) -> str:
    """Lo que el buscador contestó; si lo último que dijo es código, lo cortaron, y sale con la marca."""
    spoken = [m.text.strip() for m in log.said if m.role is Role.ASSISTANT]
    clean = [t for t in spoken if not extract_code(t)]
    text = clean[-1] if clean else spoken[-1] if spoken else NO_PROSE
    cut = not clean or bool(extract_code(spoken[-1]))
    if cut and log.fails:
        reasons = "; ".join(f.reason for f in log.fails)
        text += "\n" + CUT.format(reasons=reasons)
    return text


def sources_of(log: Log, text: str, real: Collection[str]) -> tuple[str, ...]:
    """Las rutas que el buscador señaló, por escalones: las que citó en `text`, si no las que citó en todo el turno, si no las que leyó enteras.

    Una prosa con líneas `FUENTE:` manda, aunque diga `ninguna`: es el cierre que
    pide el contrato. Sin ninguna, se buscan en todo `said`, que es donde quedan
    las que imprimió en el REPL. El corpus y los contratos de `agro.py` no tienen
    líneas que empiecen con `FUENTE:`, así que lo que casa ahí lo escribió él. Y
    si tampoco imprimió ninguna, valen las cabeceras de `read` en las salidas del
    REPL: lo que abrió entero. Ver "Las fuentes" arriba.
    """
    if citations(text):
        return existing(text, real)
    printed = existing("\n".join(m.text for m in log.said), real)
    if printed:
        return printed
    opened = read_paths("\n".join(m.text for m in log.said if m.role is Role.USER))
    return tuple(r for r in opened if r in real)


def report(who: str, real: Collection[str]) -> Rule:
    """La regla de borde: el Log de un buscador, vuelto un `Report` firmado por `who`.

    `real` son las rutas del corpus, de `paths(texto)`, y `sources` sale de
    cruzarlas con las `FUENTE:` de la prosa vía `existing`: canónicas, para
    que el que redacta las abra con `read` sin tropezar con una mayúscula.

    Va en `boundary(drive(...), report(...))`, así que lo que recibe es lo que el
    buscador AGREGÓ y no lo que venía de antes: su transcripción, su gasto, sus
    lecturas. Es el mismo delta que `Dossier.keep` guarda un paso antes.
    """
    pool = frozenset(real)
    hush = drop("said", "vote", "steps", "effects")

    def rule(log: Log) -> Log:
        text = prose(log)
        brought = Report(
            who=who,
            text=text,
            sources=sources_of(log, text, pool),
            is_grounded=log.reads > 0,
            spent=log.spent,
        )
        signed = tuple(Fail(f"{who}/{f.who}", f.reason) for f in log.fails)
        return merge(replace(hush(log), fails=signed), Log(reports=(brought,)))

    return rule


@dataclass(frozen=True, slots=True)
class Transcript:
    """Lo que un buscador dijo en un turno, firmado. Vive en el `Dossier`, nunca en el Log."""

    who: str
    said: Conversation


class Dossier:
    """El expediente del host: las transcripciones que el borde de cada buscador tira.

    Uno por agente, lo crea quien arma el orquestador y lo vacía quien sirve
    el turno. `keep(who)` es una `Rule` para `boundary`: devuelve el Log tal cual
    y se queda con una copia firmada de `said`. `drain()` entrega lo guardado
    y arranca de cero, así que un turno no arrastra el anterior.

    Es `Metered` para la transcripción: lo que el álgebra decide que no cruza,
    se mide en la fuente y se lee afuera. Con dos buscadores en `fanout` las
    dos reglas escriben en la misma lista y no se pisan, porque corren en el
    mismo loop de asyncio y `append` no cede el control.
    """

    def __init__(self) -> None:
        self._kept: list[Transcript] = []

    def keep(self, who: str) -> Rule:
        def rule(log: Log) -> Log:
            self._kept.append(Transcript(who, log.said))
            return log

        return rule

    def drain(self) -> tuple[Transcript, ...]:
        kept, self._kept = tuple(self._kept), []
        return kept


def render_reports(
    reports: tuple[Report, ...], document: Callable[[str], str], *, budget: int = SOURCES_BUDGET
) -> str:
    """Los informes como los lee el que redacta: firmados, y con cada fuente abierta entera.

    Las fuentes se abren en orden mientras entren en `budget` bytes entre todas; la primera se
    abre siempre. La que ya no entra va con su ruta y `UNOPENED`, para que el que redacta sepa
    que existe y que no la leyó. Una fuente citada por dos informes se abre una vez.

    `document` resuelve una ruta al texto del documento. Viene de afuera porque
    el corpus vive en el host y esta función no; en `agro.py` es
    `partial(read, texto)`, que ya pliega acentos y trae la ficha con su cabecera.

    Abre las fuentes y no solo las nombra a propósito. El buscador es el `grep`
    que dice dónde; el que redacta es el `read` que lee la ficha entera, con la
    equivalencia por manzana y la seguridad adentro, que es lo que una persona
    hace con una carpeta. Un informe que solo resumiera sería teléfono
    descompuesto: la respuesta saldría de lo que el buscador escribió y no de
    lo que la ficha dice.

    Un informe sin fundamento lo dice en la cabecera. El que redacta tiene que
    saber que eso no salió del corpus antes de recomendar nada con ello.
    """
    parts: list[str] = []
    used = 0
    opened: set[str] = set()
    for i in reports:
        header = f"[report from {i.who}]"
        if not i.is_grounded:
            header += f" {UNGROUNDED}"
        blocks = [header, i.text]
        for path in i.sources:
            if path in opened:
                blocks.append(f"--- {path} --- (opened further up)")
                continue
            text = document(path)
            size = len(text.encode("utf-8"))
            if opened and used + size > budget:
                blocks.append(f"--- {path} --- {UNOPENED.format(budget=budget)}")
                continue
            opened.add(path)
            used += size
            blocks.append(f"--- {path} ---\n{text}")
        parts.append("\n\n".join(blocks))
    return "\n\n".join(parts)
