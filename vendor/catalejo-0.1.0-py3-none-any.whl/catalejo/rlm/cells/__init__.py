"""Las células del turno: cada módulo fabrica una `Cell` y la mayoría arranca "La célula que...".

`handle` es la excepción a medias: no es una célula, es el turno de sistema que el
`worker` manda, y va acá porque es la mitad del worker que se lee. Lo que estas
células toman del REPL es poco y nombrable: el Protocol `Environment` (executor),
el default de `TOOLS` (handle) y `strip_accents` (citas). Ninguna sabe si el código corre en proceso o en un hijo.
"""

from catalejo.core import Registry

from .citations import cited, citations, existing, phantoms
from .effects import Resolver, Verdict, propose_effects, propose_handoff, resolve_args
from .executor import Speech, executor, extract_code, render
from .grounding import grounded
from .handle import Handle, render_handle
from .report import Dossier, Transcript, report, prose, render_reports
from .planner import checklist, planner, seed, close_steps, steer, unfinished
from .worker import window, worker

__all__ = [
    "Dossier",
    "Handle",
    "Registry",
    "Resolver",
    "Speech",
    "Transcript",
    "Verdict",
    "propose_effects",
    "checklist",
    "citations",
    "cited",
    "propose_handoff",
    "executor",
    "existing",
    "extract_code",
    "grounded",
    "phantoms",
    "planner",
    "prose",
    "render",
    "render_handle",
    "render_reports",
    "report",
    "resolve_args",
    "seed",
    "close_steps",
    "steer",
    "unfinished",
    "window",
    "worker",
]
