"""La célula que corre el código que el modelo acaba de proponer.

Su seam es un `Environment`, igual que el del worker va a ser un modelo. No muta
nada del Log: las variables del REPL son estado externo, como una base de datos.
"""

from __future__ import annotations

from collections.abc import Callable

from catalejo.core import Cell, Fail, Log, Message, Role, Status

from ..repl import Environment, Output

FENCE = "```"

OUTPUT_LIMIT = 32_000
"""Bytes de lo que imprime un bloque que el modelo lee. Cabe entero el documento más grande
de los corpus (18,7 KB, `stemcell_okf/entrevista/formulario.md`, oct 2026) con margen; un
`print` del catálogo entero (406 KB, ~110k tokens) no, y se quedaba en la ventana seis pasos."""

CUT = (
    "[output cut: showing {shown} of {total} bytes. What is missing is not lost: "
    "save the result in a variable and print only the part you need.]"
)

type Speech = Callable[[str], str | None]
"""Dado el código de un bloque, el texto que ese bloque le dice al usuario, o `None` si es código.

Es la excepción a "prosa quiere decir terminé", y la decide el host porque la
forma de la respuesta es del dominio: `agro.impreso` reconoce un bloque que solo
imprime literales con líneas `FUENTE:`.
"""


def extract_code(text: str) -> str:
    """Saca el bloque cercado CERRADO del mensaje del modelo.

    Devuelve "" en dos casos, y los dos significan "esto es una respuesta final,
    no código": que no haya cerca, y que la cerca esté abierta y sin cerrar. El
    segundo importa. Un bloque a medias, sea por unos backticks sueltos en la
    prosa o por una respuesta cortada, no puede correr como código, porque si no
    una cerca sin terminar rompe el contrato de "prosa quiere decir terminé".

    Es la única fuente de verdad sobre qué cuenta como código, así que el
    executor y el voto nunca pueden estar en desacuerdo: la FORMA de la respuesta
    decide el control.
    """
    opens = text.find(FENCE)
    if opens < 0:
        return ""
    rest = text[opens + len(FENCE) :]
    closes = rest.find(FENCE)
    if closes < 0:
        return ""
    nl = rest.find("\n")
    if 0 <= nl < closes:
        rest = rest[nl + 1 :]
        closes -= nl + 1
    return rest[:closes].strip()


def _cut(stdout: str, limit: int) -> str:
    """`stdout` hasta `limit` bytes, cortado en un fin de línea, con el aviso de cuánto faltó."""
    raw = stdout.encode("utf-8")
    if len(raw) <= limit:
        return stdout
    head = raw[:limit].decode("utf-8", errors="ignore")
    nl = head.rfind("\n")
    if nl > 0:
        head = head[:nl]
    return head + "\n" + CUT.format(shown=len(head.encode("utf-8")), total=len(raw))


def render(out: Output, limit: int = OUTPUT_LIMIT) -> str:
    """Lo que el modelo lee el turno siguiente: lo que imprimió, y el error si falló.

    Lo impreso tiene techo, `limit` bytes, y alto. En v1 había uno de 2000
    caracteres que destruía hechos: el precio del único producto de un catálogo
    caía 68 caracteres pasado el corte y el worker contestaba "no me apareció el
    precio" con el documento en la mano. Por eso este es casi el doble del documento
    más grande, corta en un fin de línea y dice que cortó y cuánto: el modelo sabe
    que el dato sigue en la variable y lo pide acotado. Sin techo, un `print` del
    corpus entero viajaba en cada paso mientras la ventana lo conservara. El error
    y las notas no se cortan.

    Si el workspace tiene `notas`, van al pie, una línea por nota. Al pie y no
    como mensaje aparte, para que `window` cuente lo mismo que antes: la ventana
    conserva las últimas salidas enteras, así que las notas están siempre en el
    prompt, y el modelo ve la suya en la salida del mismo bloque que la escribió.
    """
    parts = ["[repl] output:"]
    if out.stdout:
        parts.append(_cut(out.stdout.rstrip("\n"), limit))
    if out.err:
        parts.append(f"error: {out.err}")
    if not out.stdout and not out.err:
        parts.append("(the snippet printed nothing)")
    if out.notes:
        parts.append("[notes]\n" + "\n".join(f"- {n}" for n in out.notes))
    return "\n".join(parts)


def executor(env: Environment, *, speech: Speech | None = None) -> Cell:
    """Corre el código de la última propuesta y devuelve su salida como un dicho.

    El voto sale de la forma del mensaje, que es lo único que hace falta mirar.
    Hubo bloque quiere decir que el modelo sigue trabajando, así que vota
    CONTINUE. No hubo quiere decir que ya contestó, así que vota DONE y el loop
    corta. Por eso no hace falta un supervisor aparte: la célula que parsea la
    forma es la que sabe.

    `speech` es la única excepción a esa regla, y la pone el host. Hay un tic
    medido en 30 de 630 turnos de `agro.py` (16 de septiembre de 2026, rondas 9 a
    11 de la bitácora): el modelo escribe la respuesta entera, con sus `FUENTE:` y
    la pregunta de cierre, adentro de un `print` de un literal. Eso es prosa con
    forma de código. Sin esto, el REPL se la devuelve, el modelo gasta un turno
    en repetirla, y a veces repite solo la última línea y el cliente pierde la
    respuesta (5 de 8 en la ronda 11). Con `speech`, si el bloque es eso, se corre
    igual, porque puede traer `notas.append` que tienen que quedar, y el texto
    impreso se agrega como dicho del modelo, en prosa, y el paso vota DONE. La
    salida del REPL va adelante como turno del usuario igual que siempre, así que
    si otra célula pide otra vuelta, el modelo ve sus notas y la conversación
    sigue alternando. `reads` no sube: imprimir un literal no consulta nada.

    El gasto del Environment sube al Log. Correr Python no cuesta nada, pero un
    snippet que llama a otro modelo sí, y ese gasto tiene que cruzar el borde
    para que el `budget` del loop lo vea. Es la única vía: lo que pasa adentro
    del REPL no lo ve el álgebra.

    Un snippet que revienta NO es un `Fail`. Es flujo normal del REPL: el modelo
    ve el error en la salida y lo corrige en el bloque siguiente, y el turno sigue
    votando CONTINUE. `fails` es para cuando se rompe la maquinaria, o sea cuando
    el Environment mismo no responde, y ahí el voto queda en QUIET para que el
    loop corte en vez de seguir pidiéndole código a un REPL muerto.
    """

    async def cell(seen: Log) -> Log:
        code = extract_code(seen.said[-1].text if seen.said else "")
        if not code:
            return Log(vote=Status.DONE)
        text = speech(code) if speech is not None else None
        try:
            out = await env.run(code)
        except Exception as e:
            return Log(fails=(Fail("repl", f"{type(e).__name__}: {e}"),))
        if text is not None and not out.err:
            return Log(
                said=(Message(Role.USER, render(out)), Message(Role.ASSISTANT, text)),
                vote=Status.DONE,
                spent=out.spent,
            )
        return Log(
            said=(Message(Role.USER, render(out)),),
            vote=Status.CONTINUE,
            spent=out.spent,
            reads=1 if out.stdout else 0,
        )

    return cell
