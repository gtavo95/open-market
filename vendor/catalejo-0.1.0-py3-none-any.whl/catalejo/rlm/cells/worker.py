"""El worker raíz: la célula que le pide al modelo el próximo bloque de código.

Es la inversión de un worker común. Uno normal pliega el contexto recuperado
ADENTRO del prompt; este manda solo el handle, y el modelo alcanza el bulto
escribiendo código que corre el executor.

Por eso un modelo barato puede manejar la raíz: nunca ve el payload de 4M tokens,
solo transcripciones chicas. Esa es toda la economía del RLM.
"""

from __future__ import annotations

from catalejo.core import Cell, Conversation, Fail, Log, Message, Role
from catalejo.llm import Model

from .handle import Handle, render_handle


def window(said: Conversation, keep_recent: int, keep_first: int = 1) -> Conversation:
    """Recorta la transcripción que llega al prompt, conservando la cabeza.

    La transcripción crece cada turno, porque cada salida del REPL se apila, y
    tener el prompt chico es el punto entero del RLM. Pero quedarse solo con la
    cola pierde la pregunta original, así que a los diez hops el modelo ya no
    sabe qué le pidieron. Esto guarda los primeros `keep_first` mensajes y los
    últimos `keep_recent`.

    `keep_first` es uno por default, la pregunta. Es dos cuando el contrato de
    la célula no viene en el mensaje del host sino en uno que otra célula dijo
    justo después, como el del buscador del orquestador: un contrato que se
    recorta a los seis pasos es un contrato que el modelo deja de cumplir a los
    seis pasos.

    No toca el Log: solo cambia lo que ve el modelo, así que la transcripción
    entera sobrevive para auditar.

    El aviso del recorte no es cosmético. Le dice al modelo que lo que guardó en
    variables sigue vivo, que es la vía de recuperación de lo que se cortó.
    """
    if keep_recent <= 0 or len(said) <= keep_recent:
        return said
    cut = len(said) - keep_recent - keep_first
    if cut <= 0:
        return said
    notice = Message(
        Role.USER,
        f"[…{cut} earlier messages trimmed from the prompt. What you saved in "
        f"variables is still in the workspace.]",
    )
    return (*said[:keep_first], notice, *said[-keep_recent:])


def worker(
    model: Model,
    handle: Handle,
    *,
    keep_recent: int = 0,
    keep_first: int = 1,
    preamble: str | None = None,
) -> Cell:
    """Manda el preámbulo más la transcripción recortada, y devuelve lo que contestó.

    `model` es el que contesta. `handle` es lo que se le cuenta del contexto en el
    turno de sistema, vía `render_handle`. `keep_recent` es cuántos mensajes de la
    cola entran al prompt además de la cabeza, y `keep_first` cuántos tiene la
    cabeza; los aplica `window`, y `keep_recent=0`, el default, manda la
    transcripción entera.

    `preamble` reemplaza el turno de sistema entero cuando la célula no trabaja
    sobre un contexto grande que no ve. Es para la que redacta a partir de
    informes que ya tiene en el prompt y solo necesita el REPL para calcular:
    decirle que hay un contexto que no ve sería mentirle. Lo que el preámbulo
    propio tiene que conservar es la mecánica (un bloque de código se ejecuta,
    prosa sin backticks es terminar), porque `executor` y `grounded` la asumen.
    Con `None`, el default, va `render_handle(handle)` como siempre.

    No vota. La terminación la decide el executor mirando la forma del mensaje, y
    tenerlo en un solo lugar es lo que evita que dos células que parsean lo mismo
    se desincronicen.

    Un modelo que revienta es un `Fail` y no una excepción, igual que un
    Environment caído. El voto queda en QUIET para que el loop corte en vez de
    seguir pidiéndole texto a un proveedor que no responde.
    """

    async def cell(seen: Log) -> Log:
        system = render_handle(handle) if preamble is None else preamble
        conv = (Message(Role.SYSTEM, system), *window(seen.said, keep_recent, keep_first))
        try:
            reply = await model.complete(conv)
        except Exception as e:
            return Log(fails=(Fail("model", f"{type(e).__name__}: {e}"),))
        return Log(said=(reply.message,), spent=reply.spent)

    return cell
