"""El Workspace en un proceso aparte: lo que corre va al hijo, lo que espera y mata se queda acá.

`Workspace.run` hace dos trabajos fundidos. Uno es correr código: el namespace,
el `exec`, capturar el `print`, convertir la excepción en `err`. El otro es dónde
corre: el hilo, el lock, medir. Acá se separan por la costura que ya existía:
`Environment` es un Protocol, así que esto es un hermano de `Workspace` y nada
arriba de `run` se entera.

# Por qué un proceso y no un hilo con timeout

Un hilo no se mata. Un `while True` del modelo, o un `(a+)+$` sobre una línea
larga, se quedan hasta que muera el proceso entero (medido: más de 90 s, hubo que
matarlo a mano). `signal.alarm` solo llega al hilo principal y `re` no se
interrumpe. Lo único que se puede matar es un proceso, y eso es esto.

El mismo proceso borra la otra causa: el intérprete deja de ser compartido, así
que `json.__builtins__` llega al `open` DEL HIJO, que no tiene el cliente MCP, ni
el modelo, ni las credenciales. Lo que protege es la memoria del padre y la
posibilidad de matar. No le quita al hijo sockets ni disco; eso es otro escalón
(`resource`, o correr el hijo bajo un sandbox de verdad) y no va acá.

# Qué cruza el pipe, y qué no

El `extra` se reparte en dos por una sola pregunta: ¿es una función? Lo que no lo
es (el índice de productos, la tabla de la ontología) cruza UNA vez, como
argumento del proceso, y por eso tiene que ser picklable. Lo que sí lo es (`llm`,
`rlm`, un builtin con estado) NO cruza: se queda en el padre, y el hijo recibe un stub con
el mismo nombre que manda el pedido por el pipe, bloquea, y devuelve lo que el
padre contestó. Un builtin con estado del padre no puede correr en el hijo, y un
bound method de un objeto picklable sería peor que un error: se picklearía como
copia y las llamadas se perderían en silencio. Por eso el reparto es por
`callable` y no por lo que pickle acepte.

Ese ida y vuelta es el mismo `Bridge` con un pipe donde había un
`run_coroutine_threadsafe`. `llm` es una closure que corre la corutina en el
event loop del padre y bloquea el hilo que la llamó; acá el hilo que la llama es
el que atiende el pipe, así que `_serve_request` llama a la misma closure y la
corutina corre donde siempre. El hijo nunca ve el modelo, ni la red, ni las
credenciales: ve un nombre. Y un builtin que apila en una lista del padre apila
en el momento en que el hijo lo llama, así que quien lea esa lista después no se
entera de que hubo un proceso.

Por paso cruza `code` de ida y, de vuelta, cero o más `Request` hasta el `Output`.
Un pedido que revienta en el padre vuelve como error con el nombre del tipo, y el
hijo lo levanta con ese mismo nombre: `Output.err` dice `ValueError: ...` igual
que en proceso, y el modelo no distingue.

# De dónde sale el hijo: `forkserver`, y `spawn` donde no lo hay

Con `spawn` cada hijo era un intérprete nuevo que importaba todo otra vez. En la
imagen de agro-api, con una CPU como en Cloud Run y turnos simulados (el hijo de
verdad, esperas de modelo con `sleep`, 27 de septiembre de 2026), cada sesión
costaba ~25 MB, y diez a la vez tardaban el doble que una porque los arranques se
peleaban la CPU. Con `forkserver` el hijo es un fork de un servidor chico y
limpio que ya importó este módulo: ~9 MB por sesión, y cuarenta a la vez tardan
lo que una. El servidor no tiene hilos, ni event loop, ni conexiones, así que el
fork no hereda nada a medias, que es lo que hace a `fork` a secas peligroso en
un host con asyncio. Lo demás no cambia: el hijo se mata igual, se relanza igual,
y el `extra` cruza igual, picklado, como argumento del proceso.

Los dos reimportan el módulo principal en el hijo, así que el script que arma un
Contenedor necesita el `if __name__ == "__main__":`. Sin eso el hijo vuelve a
correr al padre, que lanza otro hijo, y los dos se quedan esperando. Los ejemplos
de `examples/` ya lo tienen.

# El timeout es flujo normal, no un Fail

Si el hijo no contesta a tiempo se mata, se relanza, y lo que vuelve es un
`Output.err` que enseña: qué pasó, que el workspace se reinició y las variables
guardadas se perdieron, y qué evitar. Es la misma regla que `_no_import`: un
error que no enseña se paga en turnos. Lo mismo si el hijo muere solo. Lo único
que levanta es no poder lanzar el proceso, y eso `executor` ya lo convierte en
`Fail("repl", ...)`, porque ahí el que falló es el host y no el snippet.

El tope corre entre mensajes, no sobre el paso entero. Mientras el padre atiende
un `llm` de un minuto el hijo está bloqueado esperando, y ese minuto no es suyo;
lo que se mide es cuánto tarda el hijo en volver a hablar.

# Las claves no llegan al hijo

`json.__builtins__` llega a `__import__`, así que el snippet que se escapa del
namespace llega a `os.environ`, y ahí estaban `OPENAI_API_KEY` y las demás: el
hijo es un fork del forkserver, y el forkserver nació con el entorno del host.
Por eso el servidor nace con un entorno sin nada más que `KEPT` (`_clean_server`,
y con él el `resource_tracker`, que nace adentro) y lo heredan todos los hijos.
En Linux, el hijo, con el mismo uid, todavía leería `/proc/<host>/environ`, que
es el entorno con el que arrancó el host: el host se marca no volcable
(`PR_SET_DUMPABLE` en 0, `_undumpable`), y su `/proc` deja de ser legible para
otro proceso que no sea root. Lo que sigue abierto: la red. Desde el hijo se
llega al servidor de metadatos de la nube y a lo que el host pueda leer por
socket; eso es otro escalón.

Lo que el proceso NO arregla, y ya está escrito en `environment.py`: la
inyección. Un corpus que le hable al modelo produce código bien formado que el
hijo corre bien, y la respuesta es mentira igual.
"""

from __future__ import annotations

import asyncio
import ctypes
import multiprocessing
import os
import pickle
import sys
import threading
from collections.abc import Callable, Mapping
from dataclasses import dataclass, replace
from multiprocessing.connection import Connection
from typing import TYPE_CHECKING, Any

from .environment import Output
from .workspace import Bridge, Workspace, tools_note

if TYPE_CHECKING:
    from multiprocessing.context import (
        ForkServerContext,
        ForkServerProcess,
        SpawnContext,
        SpawnProcess,
    )

START = "forkserver" if "forkserver" in multiprocessing.get_all_start_methods() else "spawn"
"""Cómo nace el hijo; Windows no tiene `forkserver` y queda en `spawn` (ver el docstring)."""

_CTX: SpawnContext | ForkServerContext = multiprocessing.get_context(START)  # type: ignore[assignment]
if START == "forkserver":
    # El servidor importa este módulo una vez y cada hijo lo hereda ya importado.
    # Solo vale antes de que arranque, que es en el primer `Container`.
    _CTX.set_forkserver_preload([__name__])

KEPT = ("PATH", "HOME", "LANG", "TZ", "TMPDIR")
"""Lo único del entorno del host que hereda el forkserver, y con él cada hijo, más
las `LC_*` y las `PYTHON*` que cambian cómo arranca el intérprete. Ninguna lleva
una clave; cualquier otra variable puede llevarla."""

_SERVER = threading.Lock()


def _kept(name: str) -> bool:
    return name in KEPT or name.startswith(("LC_", "PYTHON"))


def _running(pid: int | None) -> bool:
    """Si el forkserver que lanzó `multiprocessing` sigue vivo, sin cosecharlo.

    `ensure_running` lo cosecha con `waitpid` y lo relanza; si lo cosecháramos acá
    no sabría que murió. `WNOWAIT` mira sin cosechar. macOS no tiene `waitid`: ahí
    un servidor muerto y sin cosechar cuenta como vivo, y el relanzamiento sale con
    el entorno entero.
    """
    if pid is None:
        return False
    if hasattr(os, "waitid"):
        try:
            return os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is None
        except ChildProcessError:
            return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _undumpable() -> None:
    """En Linux, que otro proceso del mismo uid no lea `/proc/<host>/environ` ni su memoria."""
    if sys.platform.startswith("linux"):
        PR_SET_DUMPABLE = 4
        ctypes.CDLL(None, use_errno=True).prctl(PR_SET_DUMPABLE, 0, 0, 0, 0)


def _clean_server() -> None:
    """Lanza el forkserver con el entorno de `KEPT` si no está corriendo (ver el docstring).

    `os.environ` se vacía mientras nace el servidor y se repone enseguida. En esa
    ventana, otro hilo del host que lea una clave no la encuentra; pasa una vez por
    proceso, en el primer Contenedor, o si el servidor murió.
    """
    if START != "forkserver":
        return
    from multiprocessing import forkserver

    with _SERVER:
        _undumpable()
        if _running(forkserver._forkserver._forkserver_pid):  # type: ignore[attr-defined]
            return
        saved = dict(os.environ)
        try:
            for name in [n for n in os.environ if not _kept(n)]:
                del os.environ[name]
            forkserver.ensure_running()
        finally:
            os.environ.update(saved)


TIMEOUT = 30.0

# Cuánto se le espera al hijo para que cierre solo antes de matarlo.
GRACE = 2.0


def timeout_notice(seconds: float, var: str) -> str:
    return (
        f"the snippet did not finish in {seconds:g} s and was killed. The workspace was restarted: "
        f"`{var}` is back, but the variables you had saved were lost. "
        f"Avoid loops with no exit condition and patterns with nested repetitions like "
        f"`(a+)+`; to search, use grep(text, pattern) with a simple pattern."
    )


def died_notice(reason: str, var: str) -> str:
    return (
        f"the REPL process died while running the snippet ({reason}). It was restarted: "
        f"`{var}` is back, but the variables you had saved were lost."
    )


@dataclass(frozen=True, slots=True)
class Request:
    """Lo que el hijo manda cuando el snippet llama a un builtin que vive en el padre."""

    name: str
    args: tuple[Any, ...]
    kwargs: dict[str, Any]


@dataclass(frozen=True, slots=True)
class Response:
    """Lo que el padre contesta: el valor, o el error con el nombre de su tipo."""

    value: Any = None
    error: tuple[str, str] | None = None


def _stub(conn: Connection[Any, Any], name: str) -> Callable[..., Any]:
    """El lado del hijo de un builtin remoto: manda el pedido, espera, devuelve o levanta.

    El error se levanta con una clase que se llama como la del padre, así que lo
    que el modelo lee en `err` es lo mismo que leería en proceso.
    """

    def call(*args: Any, **kwargs: Any) -> Any:
        conn.send(Request(name, args, kwargs))
        r = conn.recv()
        if not isinstance(r, Response):
            raise RuntimeError(f"the parent answered {type(r).__name__} instead of Response")
        if r.error is not None:
            kind, reason = r.error
            raise type(kind, (Exception,), {})(reason)
        return r.value

    call.__name__ = name
    return call


def _serve(
    conn: Connection[Any, Any],
    payload: str,
    var: str,
    data: dict[str, object],
    remote: tuple[str, ...],
    two_step: bool,
    one_per_step: bool,
    peek: bool,
) -> None:
    """El lado del hijo: un Workspace y un loop que atiende snippets hasta el `None`.

    A nivel de módulo porque el hijo la busca por nombre: el servidor de
    `forkserver` ya importó este módulo, y `spawn` lo importa de cero. Llama a
    `execute`, no a `run`: acá no hay event loop que proteger.
    """
    stubs = {name: _stub(conn, name) for name in remote}
    ws = Workspace(
        payload,
        var=var,
        extra={**data, **stubs},
        two_step=two_step,
        one_per_step=one_per_step,
        peek=peek,
    )
    try:
        while True:
            code = conn.recv()
            if code is None:
                break
            conn.send(ws.execute(code))
    except EOFError:
        pass
    finally:
        conn.close()


def _split(
    extra: Mapping[str, object],
) -> tuple[dict[str, object], dict[str, Callable[..., object]]]:
    """Lo que cruza una vez y lo que se queda: datos picklables, y funciones.

    Un dato que no se puede picklear es un TypeError que dice cuál, porque el
    `extra` cruza al proceso hijo una sola vez y no hay otra forma de llevarlo.
    """
    data: dict[str, object] = {}
    remote: dict[str, Callable[..., object]] = {}
    for name, value in extra.items():
        if callable(value):
            remote[name] = value
            continue
        try:
            pickle.dumps(value)
        except Exception as e:
            raise TypeError(
                f"`{name}` cannot be pickled and `extra` crosses to the child process only "
                f"once: {type(e).__name__}: {e}"
            ) from e
        data[name] = value
    return data, remote


class Container:
    """Un `Environment` que corre el Workspace en un proceso hijo y lo mata si tarda.

    Toma lo mismo que `Workspace`, y expone lo mismo: `var`, `tools` y `bridge`,
    porque `agro.py` y `evals.py` los leen para armar el `Handle` y contar las
    lecturas delegadas. `tools` se calcula acá sin preguntarle al hijo: es una
    propiedad fija de lo que se instaló, no un hecho de la corrida.
    """

    def __init__(
        self,
        payload: str = "",
        *,
        var: str = "ctx",
        extra: Mapping[str, object] | None = None,
        note: str = "",
        bridge: Bridge | None = None,
        two_step: bool = True,
        one_per_step: bool = False,
        peek: bool = False,
        timeout: float = TIMEOUT,
        timeout_notice: Callable[[float, str], str] = timeout_notice,
        died_notice: Callable[[str, str], str] = died_notice,
    ) -> None:
        self.var = var
        self.note = note
        self.bridge = bridge
        self.two_step = two_step
        self.one_per_step = one_per_step
        self.peek = peek
        self.timeout = timeout
        # Los dos avisos que el modelo lee cuando el hijo se mató o murió, como
        # funciones de (segundos, var) y (motivo, var). Los defaults son los
        # medidos; están acá para cambiar de idioma sin heredar la clase.
        self._timeout_notice = timeout_notice
        self._died_notice = died_notice
        self._payload = payload
        self._data, self._remote = _split(extra or {})
        self._lock = asyncio.Lock()
        self._ctx = _CTX
        self._proc: SpawnProcess | ForkServerProcess | None = None
        self._conn: Connection[Any, Any] | None = None
        # Nacer y morir pasan por la misma puerta: `close()` llega desde el loop
        # mientras `_ask` corre en su hilo, y los dos tocan `_proc`.
        self._gate = threading.Lock()
        self._closed = False
        self._launch()

    @property
    def tools(self) -> str:
        base = tools_note(self.two_step, self.peek)
        return f"{base}\n\n{self.note}" if self.note else base

    @property
    def alive(self) -> bool:
        return self._proc is not None and self._proc.is_alive()

    def _launch(self) -> None:
        _clean_server()
        parent, child = self._ctx.Pipe()
        proc = self._ctx.Process(
            target=_serve,
            args=(
                child,
                self._payload,
                self.var,
                self._data,
                tuple(self._remote),
                self.two_step,
                self.one_per_step,
                self.peek,
            ),
            daemon=True,
        )
        proc.start()
        child.close()
        self._proc, self._conn = proc, parent

    def _kill(self) -> None:
        if self._proc is not None:
            self._proc.kill()
            self._proc.join()
        if self._conn is not None:
            self._conn.close()
        self._proc = self._conn = None

    def _relaunch(self) -> None:
        """Mata lo que haya y lanza un hijo nuevo, salvo que ya nos hayan cerrado.

        Es lo que hace `_ask` cuando el hijo tarda o muere, y corre en su hilo.
        Si `close()` fue el que lo mató, relanzar dejaba un hijo que nadie iba a
        cerrar; la puerta hace que el hilo espere a que `close()` termine y vea
        `_closed` antes de decidir.
        """
        with self._gate:
            self._kill()
            if not self._closed:
                self._launch()

    async def run(self, code: str) -> Output:
        """Manda el snippet al hijo y espera la respuesta, con tope.

        El lock serializa por lo mismo que en `Workspace`: el namespace del hijo
        es estado compartido. El hilo es para que la espera no congele el loop, y
        porque ahí adentro se atienden los pedidos del hijo con `bridge.wait`,
        que bloquea al hilo que lo llama. El `Bridge` se maneja igual que en
        `Workspace`: se le da el loop antes de cruzar y se mide lo que gastó.
        """
        async with self._lock:
            try:
                if self.bridge is None:
                    return await asyncio.to_thread(self._ask, code)
                self.bridge.loop = asyncio.get_running_loop()
                before = self.bridge.spent
                out = await asyncio.to_thread(self._ask, code)
                return replace(out, spent=self.bridge.spent - before)
            except asyncio.CancelledError:
                self._discard()
                raise

    def _discard(self) -> None:
        """A `run` lo cancelaron con el snippet a medias: el hilo de `_ask` sigue en el pipe.

        Un `loop` con `deadline` cancela el paso que se pasó, y `to_thread` no
        cancela hilos: el de `_ask` sigue esperando la salida del hijo, y el
        próximo `run` le mandaría otro snippet por el mismo pipe. Acá se mata
        al hijo, que es lo que hace terminar a ese hilo, y se deja `_conn` en
        `None` para que el próximo `_ask` relance en su propio hilo, no en el
        del loop. Las variables del REPL se pierden, como en un cuelgue; el
        turno que las tenía ya se cortó.
        """
        with self._gate:
            self._kill()

    def _ask(self, code: str) -> Output:
        if self._conn is None or not self.alive:
            self._relaunch()
        conn = self._conn
        if conn is None:
            raise RuntimeError(
                f"`{self.var}` is already closed: a closed Container does not relaunch the child"
            )
        # Relanzar solo si este hilo sigue hablando con el hijo actual. Después
        # de `_discard` o de un relanzamiento ajeno, el hijo que murió no es el
        # que hay que reponer, y reponerlo mataría al nuevo.
        try:
            conn.send(code)
            while True:
                if not conn.poll(self.timeout):
                    if conn is self._conn:
                        self._relaunch()
                    return Output(err=self._timeout_notice(self.timeout, self.var))
                msg = conn.recv()
                if isinstance(msg, Output):
                    return msg
                conn.send(self._serve_request(_as_request(msg)))
        except (EOFError, OSError) as e:
            if conn is self._conn:
                self._relaunch()
            return Output(err=self._died_notice(f"{type(e).__name__}: {e}", self.var))

    def _serve_request(self, p: Request) -> Response:
        """Un pedido del hijo, resuelto en el padre con la función de verdad.

        Lo que la función devuelva tiene que volver por el pipe, así que se
        picklea acá y no en el `send`: si no se puede, es un error del builtin y
        el modelo lo ve como tal, en vez de morir el pipe.
        """
        fn = self._remote.get(p.name)
        if fn is None:
            return Response(error=("NameError", f"the parent does not have `{p.name}`"))
        try:
            value = fn(*p.args, **p.kwargs)
            pickle.dumps(value)
        except Exception as e:
            return Response(error=(type(e).__name__, str(e)))
        return Response(value=value)

    def close(self) -> None:
        """Le pide al hijo que termine y, si no lo hace a tiempo, lo mata. Y no relanza más.

        `daemon=True` ya cubre el caso en que nadie llame a esto: el hijo muere
        con el padre. Esto es para no dejar procesos colgando entre tests, ni
        entre casos de un eval.

        Puede llegar con un `run` en vuelo. Un server que le pone timeout a la
        consulta entera cancela el `await` y cierra, mientras el hilo de `_ask`
        sigue esperando el pipe; ese hilo ve morir al hijo y, sin `_closed`,
        relanzaba uno nuevo que nadie iba a cerrar: un proceso huérfano por
        timeout, reproducido desde agro-api. Después de esto, `run` levanta.
        """
        with self._gate:
            self._closed = True
            if self._conn is not None:
                try:
                    self._conn.send(None)
                except OSError:
                    pass
            if self._proc is not None:
                self._proc.join(timeout=GRACE)
            self._kill()


def _as_request(x: object) -> Request:
    if not isinstance(x, Request):
        raise TypeError(f"the child sent {type(x).__name__} instead of Output or Request")
    return x
