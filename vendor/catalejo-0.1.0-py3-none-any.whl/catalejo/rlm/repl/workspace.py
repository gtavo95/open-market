"""El workspace de Python real: `exec` sobre un namespace que persiste.

Es la razón por la que el host es Python. El modelo escribe Python, así que
correrlo es `exec` en un diccionario, y los builtins recursivos que vienen
después (`llm`, `rlm`, `fanout`) van a ser funciones normales en vez de un puente
entre procesos.

# Hasta dónde llega el aislamiento

Esto NO es un sandbox. El namespace viene con los builtins recortados, sin
`import`, sin `open`, sin `eval`: alcanza para que el modelo no rompa nada por
accidente, y no alcanza contra código que se lo proponga, porque desde cualquier
objeto se llega a `__class__.__bases__` y de ahí a media biblioteca estándar.

`json` está en el namespace como módulo, así que `json.__builtins__` es un camino
derecho a `open`. No cambia la conclusión, la subraya: esto no aguanta código que
se lo proponga, y por eso lo que se le da al modelo se elige por lo que hace, no
por lo difícil que sea escaparse. `json` entra porque parsear no tiene efectos.

La frontera de verdad es el contenedor, y va después. Mientras el contexto lo
cargues vos y el modelo sea el único que escribe código, esto sirve. En el
momento en que el contexto venga de afuera, el aislamiento tiene que ser un
proceso aparte.

Tampoco hay timeout: no se puede interrumpir un `exec` en curso desde otro hilo.
Un `while True` del modelo cuelga el workspace hasta que se muera el proceso. Es
la otra cosa que arregla el contenedor.
"""

from __future__ import annotations

import asyncio
import builtins
import json
import re
import threading
import unicodedata
from collections.abc import Callable, Coroutine, Mapping
from dataclasses import dataclass, field, replace
from typing import Any, TypeVar

from .environment import Output

T = TypeVar("T")

_SAFE = (
    "abs",
    "all",
    "any",
    "bool",
    "dict",
    "divmod",
    "enumerate",
    "filter",
    "float",
    "int",
    "isinstance",
    "iter",
    "len",
    "list",
    "map",
    "max",
    "min",
    "next",
    "range",
    "repr",
    "reversed",
    "round",
    "set",
    "sorted",
    "str",
    "sum",
    "tuple",
    "type",
    "zip",
    "Exception",
    "IndexError",
    "KeyError",
    "TypeError",
    "ValueError",
)

MAX_HITS = 50

HEADER = re.compile(r"^=== (.+) ===$")

TOOLS_ONE_STEP = (
    "It is real Python with trimmed builtins: there is no `import`, `open` or `eval`. "
    "You have `grep(text, pattern)` for regular expressions: it returns the lines that "
    "match, numbered, and the first line gives the total and, if the text carries documents, "
    "in which ones and how many in each. It shows up to 50; if there are more, "
    "raise the cap with `grep(text, pattern, max_hits=500)` or narrow the pattern. It does not "
    "distinguish case or accents, so `jalapeno` finds `Jalapeño` and `raiz` finds "
    "`Raíz`; when case matters, `grep(text, pattern, exact=True)`. You have `json` "
    "without importing it, for `json.loads` on a block that comes from the context. If the text "
    "carries documents separated by a `=== path ===` line, each result comes out as "
    "`path:line: content`, so you do not need to look for which file it belongs to. "
    "That prefix is added when printing and is NOT part of what is searched: a pattern that "
    "includes it, like `products/x\\.md:.*dose`, never matches and returns zero. To look at a "
    "single document, `grep(text, pattern, doc='x')`, which compares against the path. The "
    "`=== path ===` line is not content: if the pattern matches it, the first line names "
    "the document without adding it to the total. "
    "The rest of Python works as usual: slicing, `len`, comprehensions, `sorted`."
)

_BEFORE_READ = (
    "It is real Python with trimmed builtins: there is no `import`, `open` or `eval`. "
    "The text carries documents separated by a `=== path ===` line, and querying it takes "
    "two steps, like searching a folder and then opening the file. First "
    "`grep(text, pattern)` tells you how many lines match and in which documents, how many in "
    "each, without showing the lines. "
)

_READ_WHOLE = (
    "Then `read(text, 'part of the path')` returns "
    "that whole document, as is, so you read the fact with everything around "
    "it. "
)

_READ_PEEK = (
    "Then `read(text, 'part of the path')` returns the header and the frontmatter of "
    "that document (title, tags, certified crops), which is enough to decide whether it works; "
    "the whole document is read later by whoever writes the reply, not by you. "
)

_AFTER_READ = (
    "If you only want the lines that match inside a document, "
    "`grep(text, pattern, doc='part of the path')`, and each one comes out as "
    "`path:line: content`. What counts is what the document says; the `grep` summary "
    "serves to choose what to read, not to answer. `pattern` is a regular "
    "expression. It does not distinguish case or accents, so `jalapeno` finds `Jalapeño` and "
    "`raiz` finds `Raíz`; when case matters, `grep(text, pattern, exact=True)`. "
    "The `=== path ===` line is not content: if the pattern matches it, the first line "
    "names the document without adding it to the total. With `doc=` it shows up to 50 lines, and "
    "if there are more it tells you how to ask for the rest. If the text carries no documents, "
    "`grep` shows the lines directly. You have `json` without importing it, for `json.loads` on "
    "a block that comes from the context. The rest of Python works as usual: slicing, `len`, "
    "comprehensions, `sorted`."
)

TOOLS = _BEFORE_READ + _READ_WHOLE + _AFTER_READ
TOOLS_PEEK = _BEFORE_READ + _READ_PEEK + _AFTER_READ
"""La nota de dos pasos cuando `read` asoma en vez de leer: cambia solo la oración de `read`."""


def tools_note(two_step: bool, peek: bool = False) -> str:
    """La nota de herramientas que corresponde a lo que el REPL tiene instalado.

    `TOOLS` es la de dos pasos porque es el default; la de un paso, la de
    antes del 2026-09-13, se queda con nombre propio para el arm que la apaga.
    `peek` es la de dos pasos con un `read` que muestra la cabecera y el
    frontmatter y nada más; sin `two_step` no hay `read` y no significa nada.
    """
    if not two_step:
        return TOOLS_ONE_STEP
    return TOOLS_PEEK if peek else TOOLS


def paths(text: str) -> frozenset[str]:
    """Las rutas que EXISTEN en el texto: las cabeceras `=== ruta ===`.

    Vive al lado de `HEADER` y no en `citations.py` porque es conocimiento del formato
    del corpus, el mismo que usa `grep` para prefijar cada hit con su documento. La
    cita se verifica contra esto, pero esto no sabe qué es una cita.
    """
    return frozenset(m.group(1) for m in map(HEADER.match, text.splitlines()) if m)


def _no_import(name: str, *_: object, **__: object) -> object:
    """El `import` que no hay, explicado.

    Sin esto Python levanta `ImportError: __import__ not found`, que no le dice al
    modelo qué hacer en su lugar. Dos corridas contra Gemini se perdieron ahí: pidió
    `re` una vez y `collections` la otra, y las dos veces el error no lo llevó a
    ninguna parte. Un error que no enseña se paga en turnos, o peor: una de las dos
    veces el modelo dejó de intentar y contestó de memoria.
    """
    raise ImportError(
        f"there is no `import` in this REPL, so `{name}` is not available. "
        f"`json` is already in the namespace, use it without importing it. For regular "
        f"expressions use grep(text, pattern). To count, a dict: "
        f"`c = {{}}; c[k] = c.get(k, 0) + 1`. The rest of Python works as usual."
    )


def strip_accents(s: str) -> str:
    """La misma cadena sin marcas diacríticas.

    Descompone en NFD y tira las combinantes, así que también pliega la eñe:
    `araña` y `arana` quedan iguales. Es agresivo a propósito, porque el modelo
    escribe el término tal como lo dice el cliente y el cliente no pone tildes.
    """
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


@dataclass(slots=True)
class _Folded:
    """Un texto ya partido en líneas, y esas líneas ya sin acentos."""

    text: str
    lines: list[str] = field(default_factory=list)
    field: list[str] | None = None


MAX_FOLDED = 8

_FOLDED: dict[int, _Folded] = {}
_LOCK = threading.Lock()


def _fold(text: str, *, fold: bool) -> tuple[list[str], list[str]]:
    """Las líneas del texto y su copia buscable, calculadas una sola vez por texto.

    El costo de `grep` no estaba en la regex, estaba acá. Sobre el corpus de 7,2 MB
    de `examples/tickets.py`, una llamada tardaba 637 ms y 574 de esos eran plegar los acentos
    del corpus ENTERO, de nuevo, en cada llamada. Con el plegado guardado la misma
    búsqueda tarda 50 ms. El modelo no ve ninguna diferencia: mismos hits, misma
    cabecera. Por eso esto no lleva fila en la bitácora, que mide tokens y aciertos
    y no tiene columna de milisegundos.

    La clave es `id(texto)` y el texto se guarda al lado, que es lo que hace segura
    la clave: mientras el diccionario lo referencia, ese objeto no se libera y su
    `id` no se puede reusar para otro. La comparación real es `is`, no `==`, porque
    comparar dos corpus de 7 MB por contenido cuesta lo mismo que plegarlos.

    Ocho entradas porque ocho es `PARALLEL`: un `fanout` entero puede tener su
    plegado sin pisarse. Cada hijo recibe un pedazo, así que lo que el caché puede
    llegar a retener está acotado por el texto que ya estás teniendo en memoria,
    duplicado. Cuando se llena sale el más viejo.

    `exacto=True` no pliega nada y por eso `field` se calcula recién cuando alguien
    lo pide. Sobre el corpus de código Go, donde `Plan` y `plan` son cosas
    distintas, plegar sería trabajo tirado.
    """
    saved = _FOLDED.get(id(text))
    if saved is None or saved.text is not text:
        saved = _Folded(text, text.splitlines())
        with _LOCK:
            if len(_FOLDED) >= MAX_FOLDED:
                _FOLDED.pop(next(iter(_FOLDED)))
            _FOLDED[id(text)] = saved
    if not fold:
        return saved.lines, saved.lines
    if saved.field is None:
        saved.field = [strip_accents(line) for line in saved.lines]
    return saved.lines, saved.field


def grep(
    text: str,
    pattern: str,
    max_hits: int = MAX_HITS,
    *,
    exact: bool = False,
    doc: str = "",
    show: bool = True,
) -> str:
    r"""Las líneas que casan con el patrón, numeradas, con el total adelante.

    `text` es donde se busca, línea por línea. `pattern` es una regex de `re`, no
    un literal: los puntos y los paréntesis hay que escaparlos. `max_hits` es
    cuántas líneas se muestran como mucho; el total se cuenta igual y se dice
    siempre. `exacto`, `doc` y `show` van más abajo, cada uno con su motivo.

    Pliega mayúsculas y acentos, y ese default no es comodidad. Sobre el catálogo
    agronómico, `mosca blanca` en minúscula devolvía 6 de las 23 líneas que hay, y
    `arana roja` sin la eñe devolvía cero con seis en el texto. El modelo no tiene
    forma de enterarse: recibe un número que parece el total. Es el mismo error que
    el tope silencioso, que ya está resuelto dos párrafos más abajo, entrando por
    otra puerta.

    El patrón NO se pasa a minúsculas, se le sacan los acentos y las mayúsculas van
    por la bandera. En una regex `\S`, `\D`, `\W` y `\B` significan lo contrario
    que sus versiones minúsculas, así que bajar el patrón entero convierte "no
    espacio" en "espacio" y rompe en silencio cualquier búsqueda con clases.

    `exacto=True` para cuando el caso es el dato: sobre un corpus de código Go,
    `Plan` y `plan` son cosas distintas.

    `doc="fungiban"` acota la búsqueda a los documentos cuya ruta contenga eso, y
    existe por un cero falso medido. El resultado sale prefijado con `ruta:`, así
    que el modelo deduce lo razonable y escribe `productos/fungiban\.md:.*DOSIS`
    para mirar una sola ficha. Ese prefijo se arma al imprimir y no está en el
    texto sobre el que se busca, así que el patrón no casa nunca. En la suite
    agronómica contra luna pasó cinco veces en una sola corrida, todas en el caso
    que pregunta si un dato ESTÁ, que es donde un cero falso se vuelve una
    respuesta segura y equivocada. Ese caso se llevó 223 mil de los 503 mil
    tokens de la suite.

    Un `doc` que no casa con ningún documento se dice con todas las letras, por lo
    mismo que se dice el cero: "no hay líneas en esa ficha" y "esa ficha no existe"
    son dos respuestas distintas y el modelo tiene que poder separarlas.

    Cuando el texto es una concatenación de documentos con la línea `=== ruta ===`
    adelante, cada hit sale con su documento. Es la diferencia entre encontrar y
    saber qué encontraste: sobre el catálogo agronómico, un hit cae a una mediana de
    119 líneas de su cabecera y a 230 en el peor eje, así que averiguar de qué
    producto era la línea 5157 costaba imprimir una ventana y caminar para atrás.
    Una corrida se fue a 108 mil tokens haciendo justamente eso. El dato ya estaba en
    el texto y no viajaba con el resultado; ahora viaja.

    La primera línea habla en documentos, porque en un corpus de fichas la unidad es
    la ficha y no la línea. Medido sobre el catálogo: `pulgon` son 24 líneas en 3
    documentos (una ficha 12, objetivos 7, otra ficha 5) y `cogollero` 6 en 2. Esa lista
    es el esqueleto de la respuesta, qué productos y aparte qué dice el vocabulario,
    y antes el modelo la reconstruía leyendo 24 prefijos. Va ordenada por cantidad
    de líneas y con el mismo tope que las líneas, anunciado igual.

    La cabecera `=== ruta ===` no es contenido y no cuenta. Como contiene la ruta, un
    patrón que nombra un producto o una carpeta casaba con ella: `productos` daba
    120 líneas de las que 39 eran cabeceras, y el nombre de una ficha 13 con 1. En un agente
    cuyo argumento es contar bien, eso es un total inflado. Pero saltarla en
    silencio convierte `grep(ctx, '===')`, que es la forma natural de listar los
    documentos de un texto sin índice, en un cero falso, y un nombre con guion daría una
    línea suelta del índice sin decir que la ficha existe con ese nombre. Así que
    cuando el patrón casa con una cabecera, la primera línea nombra el documento y
    no lo suma. Lo que se compra es el número correcto y el resumen por documento;
    los tokens casi no cambian, porque bajo el tope las cabeceras eran líneas
    baratas y su lugar lo ocupan líneas de contenido más largas.

    `mostrar=False` es el modo de dos pasos, y no lo elige el modelo: lo fija el
    `Workspace`, que lo instala así por default. Cuando el texto trae documentos y
    no se pidió uno con `doc=`, el resultado es la primera línea sola, la que dice
    en qué documentos y cuántas en cada uno. El contenido llega recién cuando el
    modelo nombra el documento, con `doc=` acá o con `read`. Es lo que hace la
    búsqueda de Codex CLI, que devuelve rutas y nada más, y lo que hace una
    persona: buscar, elegir qué abrir, y leer. Lo que hace imposible es contestar
    desde una línea suelta del grep, fuera de su ficha. Las líneas que caen fuera
    de todo documento se muestran igual, porque no hay nombre con el cual
    pedirlas; y si el texto no trae documentos, el modo no cambia nada.

    Esta función, llamada directo, muestra las líneas: es el primitivo, y los
    tests lo fijan así. Lo que el modelo tiene en el namespace es
    `_grep_two_step`, salvo que el que arma el REPL pida `dos_pasos=False`.

    Que pliega va dicho en `TOOLS` y no en la cabecera de cada resultado,
    porque es una propiedad fija de la herramienta y no un hecho de esta corrida.
    La cabecera dice lo que cambia entre llamada y llamada, que es cuántas hay y
    cuántas se muestran.

    Existe porque `re` no es importable. Un contexto grande se recorre con esto,
    no imprimiéndolo: el punto del RLM es que el bulto nunca entre al prompt.

    El total va SIEMPRE y va PRIMERO, y no es cosmética. Un tope que no se anuncia
    convierte "contá cuántos hay" en una respuesta falsa que parece verdadera: en
    la primera corrida contra Gemini el modelo contó las 50 líneas que le
    devolvimos y contestó 50, sobre un corpus con 1823. Había pedido el dato
    correcto y le mentimos. Un tope silencioso es peor que no tener tope, porque
    el error no se ve. Este dice cuántas hay, cuántas muestra y cómo pedir el resto.

    Cero coincidencias también se dice con todas las letras. Devolver "" es
    indistinguible de un snippet que no imprimió nada.
    """
    lines, field = _fold(text, fold=not exact)
    rx = re.compile(pattern) if exact else re.compile(strip_accents(pattern), re.IGNORECASE)
    filter_rx = strip_accents(doc).lower()
    hits: list[str] = []
    loose_ones: list[str] = []
    looked: list[str] = []
    per_doc: dict[str, int] = {}
    headers: list[str] = []
    current = ""
    inside = not filter_rx
    for i, (original, searchable) in enumerate(zip(lines, field), 1):
        head = HEADER.match(original)
        if head:
            current = head.group(1)
            inside = not filter_rx or filter_rx in strip_accents(current).lower()
            if inside and filter_rx:
                looked.append(current)
            if inside and rx.search(searchable):
                headers.append(current)
            continue
        if inside and rx.search(searchable):
            if current:
                hits.append(f"{current}:{i}: {original}")
                per_doc[current] = per_doc.get(current, 0) + 1
            else:
                hits.append(f"{i}: {original}")
                loose_ones.append(hits[-1])
    if filter_rx and not looked:
        return (
            f"no document matches {doc!r}, so nothing was searched. `doc` is compared "
            f"against the path on the `=== path ===` line, not against the content."
        )
    ranking = sorted(per_doc.items(), key=lambda pair: -pair[1])
    listing = _listing([f"{path} ({n})" for path, n in ranking], max_hits)
    if filter_rx and len(looked) == 1:
        scope = f" in {looked[0]}"
    elif filter_rx and not ranking:
        scope = f" in the {len(looked)} documents that match {doc!r}"
    elif filter_rx and len(ranking) == len(looked):
        scope = f" in the {len(looked)} documents that match {doc!r}: {listing}"
    elif filter_rx:
        scope = f" in {len(ranking)} of the {len(looked)} documents that match {doc!r}: {listing}"
    elif len(ranking) == 1:
        scope = f" in {ranking[0][0]}"
    elif ranking:
        scope = f" in {len(ranking)} documents: {listing}"
    else:
        scope = ""
    matching = "matches" if len(hits) == 1 else "match"
    line = "line" if len(hits) == 1 else "lines"
    header = f"{len(hits)} {line} {matching} {pattern!r}{scope}."
    if not show and not filter_rx and per_doc:
        if len(loose_ones) > max_hits:
            header += (
                f" {len(loose_ones)} of those fall outside any document and are shown; these "
                f"are the first {max_hits}."
            )
        hits = loose_ones[:max_hits]
    elif len(hits) > max_hits:
        rest = "raise max_hits, narrow the pattern or restrict with doc=" if per_doc else "raise max_hits or narrow the pattern"
        header = (
            f"{len(hits)} lines match {pattern!r}{scope}; these are the first "
            f"{max_hits}. For the rest {rest}."
        )
        hits = hits[:max_hits]
    loose = [path for path in headers if path not in per_doc]
    if loose:
        how_many = f"{len(loose)}{' more' if per_doc else ''} document" + ("s" if len(loose) != 1 else "")
        header += (
            f" The `=== path ===` header of {how_many} matches the "
            f"pattern and does not count as content: {_listing(loose, max_hits)}."
        )
    return "\n".join([header, *hits])


def _grep_two_step(
    text: str,
    pattern: str,
    max_hits: int = MAX_HITS,
    *,
    exact: bool = False,
    doc: str = "",
) -> str:
    """El `grep` que el `Workspace` instala por default: el mismo, sin la puerta.

    Es una función y no un `partial` para que `show` no exista desde el REPL:
    si el modelo pudiera pedir las líneas con un argumento, el modo no sería el
    modo, sería una sugerencia.
    """
    return grep(text, pattern, max_hits, exact=exact, doc=doc, show=False)


def _listing(items: list[str], cap: int) -> str:
    """Una lista en una línea, y si pasa del tope dice cuántas quedaron afuera."""
    if len(items) <= cap:
        return ", ".join(items)
    return ", ".join(items[:cap]) + f" and {len(items) - cap} more"


def _documents(lines: list[str]) -> list[tuple[str, int, int]]:
    """Cada documento del texto: su ruta y el rango de líneas de contenido.

    Los números son los mismos que usa `grep`, la posición en el texto entero y
    desde 1, así que el rango que `read` anuncia y el prefijo de un hit hablan de
    la misma línea. El rango va de la línea que sigue a la cabecera hasta la
    anterior a la siguiente cabecera; un documento vacío tiene el fin antes del
    inicio.
    """
    docs: list[tuple[str, int, int]] = []
    path = ""
    start = 0
    for i, line in enumerate(lines, 1):
        head = HEADER.match(line)
        if not head:
            continue
        if path:
            docs.append((path, start, i - 1))
        path, start = head.group(1), i + 1
    if path:
        docs.append((path, start, len(lines)))
    return docs


def read(text: str, doc: str) -> str:
    """Un documento entero, tal cual está en el texto, para leerlo con su contexto.

    Es el segundo paso del modo de dos pasos: `grep` dice en qué documento está
    el dato y esto lo trae para que el modelo lo lea con lo que lo rodea, que es
    lo que una línea suelta no tiene. En el catálogo agronómico la línea 5157 de
    una ficha dice "gusano cogollero. 1.4 L/ha" con el cultivo en la línea anterior
    y la tabla con la equivalencia por manzana en la 5286; leer la ficha es la
    única forma de ver las tres juntas.

    `doc` se compara contra la ruta igual que en `grep`, plegando caso y acentos,
    y una ruta escrita entera gana sobre las que la contienen: `nutrifol.md` es
    esa ficha aunque exista `nutrifol-plus.md`. Varias rutas que casan no se
    imprimen todas, se listan y se pide elegir, porque dos fichas juntas son el
    doble de tokens sin que nadie las haya pedido. Cero rutas y cero documentos
    son dos avisos distintos, por lo mismo que en `grep`.

    El contenido sale sin numerar. Una ficha mediana son 181 líneas, y un prefijo
    por línea es un quinto más de tokens para un dato que el modelo no usa al
    contestar; el rango de líneas va en la primera línea, con los mismos números
    que usa `grep`, para que `grep(texto, patron, doc=...)` y esto se lean juntos.

    No hay tope, a propósito. La razón de esta función es que el modelo vea el
    dato con todo lo que lo rodea, y un tope que corta la ficha en la línea 400
    devuelve el problema que esto vino a sacar: un dato sin su contexto, ahora
    con la forma de una ficha entera. Sobre el catálogo ninguna pasa de 286
    líneas. El corpus donde un documento son miles de líneas paga esos tokens, y
    esa es la decisión: entero o nada, y "nada" se pide con `grep(doc=)`.

    Lo que sí tiene tope es cuántos enteros por bloque, y eso no vive acá sino en
    el Workspace, que es el que sabe dónde empieza y termina un bloque: ver
    `Workspace._read`. Esta función es una llamada suelta y devuelve siempre todo.
    """
    found = _resolve(text, doc)
    if isinstance(found, str):
        return found
    return _whole(*found)


Document = tuple[str, int, int, list[str]]
"""Un documento resuelto: ruta, primera y última línea de contenido, y las líneas del texto."""


def _resolve(text: str, doc: str) -> str | Document:
    """La mitad de `read` que resuelve la ruta: el documento, o el aviso de por qué no.

    Separada del render porque hay dos renders: el entero, que es `read`, y el
    asomo que devuelve el Workspace cuando en el mismo bloque ya salió un documento
    entero (`Workspace._read`). Los avisos son los mismos en los dos, así que la
    resolución vive una sola vez.
    """
    lines, _ = _fold(text, fold=False)
    docs = _documents(lines)
    if not docs:
        return (
            "the text carries no documents (no `=== path ===` line), so there is nothing "
            "to read by name. Search it with grep(text, pattern), which here shows the lines."
        )
    filter_rx = strip_accents(doc).lower()
    candidatos = [d for d in docs if filter_rx in strip_accents(d[0]).lower()]
    exact_ones = [d for d in candidatos if strip_accents(d[0]).lower() == filter_rx]
    if exact_ones:
        candidatos = exact_ones
    if not candidatos:
        return (
            f"no document matches {doc!r}. `doc` is compared against the path on the "
            f"`=== path ===` line, not against the content; grep(text, pattern) tells you which ones it is in."
        )
    if len(candidatos) > 1:
        how_many = len(candidatos)
        return (
            f"{how_many} documents match {doc!r}: "
            f"{_listing([d[0] for d in candidatos], MAX_HITS)}. Pick one by writing more of the path."
        )
    path, start, end = candidatos[0]
    if end - start + 1 <= 0:
        return f"{path} is empty: the header and nothing else."
    return path, start, end, lines


def _header_line(path: str, start: int, end: int) -> str:
    total = end - start + 1
    return f"{path}: {total} {'line' if total == 1 else 'lines'}, from {start} to {end}."


READ_HEADER = re.compile(r"^(\S+): \d+ lines?, from \d+ to \d+\.$", re.MULTILINE)
"""La cabecera de `read` sola en su línea: así abre un documento entero, y así abre `_peek_only`.

El asomo de `one_per_step` (`_peek_after`) abre con la misma cabecera y sigue en la
misma línea ("Un documento entero por bloque..."), así que el `$` lo deja afuera
a propósito: ahí el modelo ya leyó otro entero y a este solo lo vio pasar. En
`_peek_only` la cabecera va sola porque el asomo es todo lo que `read` da.
"""


def read_paths(salida: str) -> tuple[str, ...]:
    """Las rutas que `read` abrió en `salida`, en orden y sin repetir.

    Vive al lado de `_header_line` por la misma razón que `paths` vive al lado de
    `HEADER`: es conocimiento del formato, y el que lo escribe es el que lo
    parsea. Lo usa `report.sources_of` como último escalón: un buscador que
    abrió una ficha y no la citó igual la tuvo delante, y la que redacta puede
    citarla ella. Es un piso, como `agro.leyo`: dice que el documento pasó, no
    que se usó.
    """
    return tuple(dict.fromkeys(m.group(1) for m in READ_HEADER.finditer(salida)))


HIT = re.compile(r"^(\S+):\d+: ", re.MULTILINE)
"""Una línea de `grep` con documento: `ruta:N: texto`, como la arma `_grep`.

Las sueltas, `N: texto`, no tienen ruta y no casan. La cabecera de `read` tampoco,
porque después de la ruta lleva un espacio y no un número.
"""


def seen_paths(salida: str) -> tuple[str, ...]:
    """Las rutas que pasaron por delante del modelo en `salida`: las que `read` abrió y las que `grep` nombró en un hit.

    Es lo que mira `agro.leyo`, la compuerta "vio este archivo", y es más laxo
    que `read_paths` a propósito: un hit de grep muestra una línea del documento, y
    para el piso de una compuerta con eso alcanza. Para citar una fuente no, y
    por eso `report.sources_of` usa `read_paths`. Los dos parsers viven acá, al lado
    de `_header_line` y de `_grep`, por la regla de un solo parser: si la cabecera
    o el hit cambian de forma, esto cambia en el mismo archivo.
    """
    marks = [(m.start(), m.group(1)) for rx in (READ_HEADER, HIT) for m in rx.finditer(salida)]
    return tuple(dict.fromkeys(path for _, path in sorted(marks)))


def _whole(path: str, start: int, end: int, lines: list[str]) -> str:
    return "\n".join([_header_line(path, start, end), *lines[start - 1 : end]])


def _frontmatter(start: int, end: int, lines: list[str]) -> list[str]:
    """El bloque entre `---` con que abre el documento, con sus dos rayas, o nada.

    Es la única convención de markdown que `read` conoce, y la conoce porque es
    lo que un modelo va a buscar cuando compara documentos: título, tags, los
    cultivos certificados. Un documento que no abre con `---` no tiene frontmatter
    y el asomo es solo la cabecera.
    """
    if lines[start - 1].strip() != "---":
        return []
    for i in range(start, end):
        if lines[i].strip() == "---":
            return lines[start - 1 : i + 1]
    return []


def _peek_after(path: str, start: int, end: int, lines: list[str], *, already: str) -> str:
    """Lo que devuelve `read` cuando en este bloque ya salió un documento entero.

    La cabecera, el frontmatter y qué hacer para tener el resto. El frontmatter
    va porque es lo que el modelo estaba comparando: en la ronda del 16 de
    septiembre de 2026 pidió tres fichas enteras, 36.000 caracteres, para mirar
    los cultivos certificados de cada una, que son 12 líneas del frontmatter. Sin
    el frontmatter se quedaría sin el dato y gastaría dos bloques en pedirlo.
    """
    where = "it already came out whole, further up" if already == path else f"{already} already came out whole"
    notice = (
        f"{_header_line(path, start, end)} One whole document per block, and in this one {where}: "
        f"of {path} only the frontmatter goes. To read it whole, read(text, {path!r}) in the "
        f"next block; for a specific fact, grep(text, pattern, doc={path!r})."
    )
    return "\n".join([notice, *_frontmatter(start, end, lines)])


def _peek_only(path: str, start: int, end: int, lines: list[str]) -> str:
    """Lo que devuelve `read` cuando el REPL asoma: la cabecera sola, el frontmatter, y a quién le toca el resto.

    La cabecera va sola en su línea a propósito, como en el documento entero y
    al revés que en `_peek_after`: acá el asomo es todo lo que `read` da, así que
    pedirlo es abrir la ficha, y `read_paths` la cuenta. En `_peek_after` la cabecera
    sigue en la misma línea porque ahí el modelo ya leyó otro documento entero
    en el bloque y este solo lo vio pasar.
    """
    notice = (
        f"Of {path} only the frontmatter goes here: the whole document is read by whoever writes the reply. "
        f"For a specific fact, grep(text, pattern, doc={path!r})."
    )
    return "\n".join([_header_line(path, start, end), *_frontmatter(start, end, lines), notice])


@dataclass
class Bridge:
    """El paso del hilo del `exec` al event loop, y el medidor de lo que cruza.

    El modelo escribe código síncrono. Llamar a otro modelo es una corutina. El
    `exec` corre en un hilo aparte, así que ahí adentro no se puede hacer `await`
    de nada: `run_coroutine_threadsafe` es el puente, y bloquea SOLO a ese hilo
    mientras el event loop sigue atendiendo a todos los demás.

    Cuenta lo gastado porque este es el único lugar por donde pasa. Todo lo que
    consume el árbol recursivo nace de una llamada que cruzó por acá, así que
    medirlo acá es medirlo todo, y `Output.spent` lo sube al Log del padre.

    Las mutaciones de `spent` pasan siempre en el hilo del event loop, adentro de
    la corutina, así que no hace falta lock aunque haya varios `exec` en paralelo.
    """

    budget: int = 0
    spent: int = 0
    calls: int = 0
    loop: asyncio.AbstractEventLoop | None = None

    @property
    def left(self) -> int:
        return max(0, self.budget - self.spent)

    def wait(self, coro: Coroutine[Any, Any, T]) -> T:
        """Corre la corutina en el event loop y bloquea este hilo hasta que vuelva."""
        if self.loop is None:
            coro.close()
            raise RuntimeError("no event loop: this runs from the model's code")
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result()


class Workspace:
    """Un REPL de Python con el contexto grande adentro, en `var`.

    Las variables persisten entre corridas, así que el modelo puede guardar un
    hallazgo en vez de depender de releer la transcripción, que se va recortando.

    Consultar el contexto son dos pasos por default: `grep` sin `doc=` devuelve
    solo dónde, y `read` trae un documento entero. `dos_pasos=False` restaura el
    `grep` que mostraba las líneas, sin `read`, y la nota de `tools` cambia con
    él, porque un builtin que no se nombra es un builtin que el modelo no usa.
    Se midió (filas `two_step` de la bitácora, 2026-09-13): mismos aciertos,
    mismo costo dentro del ruido, medio turno más, y la respuesta sale de la
    ficha entera en vez de una línea. Es default por eso último, que `acierta()`
    no mide y el que atiende sí.

    `asoma=True` es el REPL de un buscador que no redacta: `read` devuelve la
    cabecera y el frontmatter, nunca el documento, y la nota de `tools` lo dice.
    Existe por el orquestador (`agro.buscador`), donde la ficha se pagaba dos
    veces, entera en el REPL del buscador y entera otra vez en el pedido de la
    redactora; en la ronda 13 de la bitácora (17 de septiembre de 2026) eso era
    el +23% sobre el agente de un loop. El buscador decide con el índice, `grep`
    y el frontmatter, que es donde están los tags y los cultivos certificados; la
    redactora es la única que lee entero.

    Medido y perdió (fila `complejos_orquestar_asoma_low_r14`, misma fecha):
    17/20 contra 18/20, 53/60 contra 58/60, y el buscador costó MÁS, 21,002 por
    turno contra 16,126, con más pasos (5 a 8 en vez de 4 a 5) y más consultas
    (193 contra 167). Sin la ficha el modelo no se conforma con el frontmatter:
    vuelve al índice, prueba expresiones sin `print`, grepea de más, y en un
    caso (un producto pedido para araña roja, que hay que corregir a otro)
    llegó al tope de pasos tres veces de tres sin abrir nada. La ficha entera es
    lo que le da la seguridad de que ya encontró; sacársela no ahorra la ficha,
    la reemplaza por más pasos. Queda como bandera apagada, por si el corpus
    cambia de forma; no es palanca del costo.
    """

    def __init__(
        self,
        payload: str = "",
        *,
        var: str = "ctx",
        extra: Mapping[str, object] | None = None,
        note: str = "",
        bridge: Bridge | None = None,
        two_step: bool = True,
        one_per_step: bool = False,
        peek: bool = False,
    ) -> None:
        self.var = var
        self.note = note
        self.bridge = bridge
        self.two_step = two_step
        self.one_per_step = one_per_step
        self.peek = peek
        self._output: list[str] = []
        self._wholes: list[str] = []
        self._lock = asyncio.Lock()
        self._globals: dict[str, object] = {
            "__builtins__": {
                **{name: getattr(builtins, name) for name in _SAFE},
                "print": self._print,
                "__import__": _no_import,
            },
            "grep": grep,
            "json": json,
            **({"grep": _grep_two_step, "read": self._reader()} if two_step else {}),
            **(extra or {}),
            var: payload,
        }

    @property
    def tools(self) -> str:
        """La nota del preámbulo: qué ofrece ESTE workspace.

        Vive acá y no en el `Handle` porque solo el Environment sabe qué tiene
        adentro. Un builtin que se agrega sin actualizar la nota es un builtin
        que el modelo nunca va a usar, porque no sabe que existe.
        """
        base = tools_note(self.two_step, self.peek)
        return f"{base}\n\n{self.note}" if self.note else base

    def _print(self, *args: object, sep: str = " ", end: str = "\n") -> None:
        self._output.append(sep.join(str(a) for a in args) + end)

    def _reader(self) -> Callable[[str, str], str]:
        """El `read` que este workspace instala: el que asoma, el de uno por bloque, o el pelado."""
        if self.peek:
            return self._peek
        return self._read if self.one_per_step else read

    def _peek(self, text: str, doc: str) -> str:
        """`read` que nunca da el documento: cabecera, frontmatter y a quién le toca el resto. Ver `peek`."""
        found = _resolve(text, doc)
        if isinstance(found, str):
            return found
        path, start, end, lines = found
        return _peek_only(path, start, end, lines)

    def _read(self, text: str, doc: str) -> str:
        """`read` con la regla de un documento entero por bloque.

        La primera llamada del bloque devuelve el documento como `read`. Las
        siguientes devuelven el asomo: cabecera, frontmatter y cómo pedir el
        resto. `read` suelto ya se niega a imprimir dos documentos cuando la ruta
        casa con dos, porque "dos fichas juntas son el doble de tokens sin que
        nadie las haya pedido"; esto extiende la misma regla a las llamadas de un
        mismo bloque, que `read` no puede ver porque no sabe qué es un bloque.

        Lo que motivó la regla: en la ronda del 16 de septiembre de 2026, cinco
        turnos de 45 hicieron `for ruta in [...]: print(read(catalogo, ruta))`
        sobre tres fichas, 36.000 a 42.500 caracteres en una sola salida, y eran
        un tercio de todo lo que `read` devolvió en la ronda. Cuenta llamadas, no
        impresiones: `a = read(...)` sin `print` también gasta el entero del bloque.

        No es default: `uno_por_paso=False` ata `read` pelado, que devuelve todo lo
        que se le pida. Por qué quedó a un flag lo cuenta `agro.armar`.
        """
        found = _resolve(text, doc)
        if isinstance(found, str):
            return found
        path, start, end, lines = found
        if not self._wholes:
            self._wholes.append(path)
            return _whole(path, start, end, lines)
        return _peek_after(path, start, end, lines, already=self._wholes[0])

    async def run(self, code: str) -> Output:
        """Corre el snippet y devuelve lo que imprimió.

        Serializa con un lock porque el namespace es estado compartido: un
        `fanout` que le pase el mismo workspace a varias células no puede
        pisarse. Y va a un hilo para que un grep sobre 4M de texto no congele el
        resto de las corutinas mientras esperan al modelo.
        """
        async with self._lock:
            if self.bridge is None:
                return await asyncio.to_thread(self.execute, code)
            self.bridge.loop = asyncio.get_running_loop()
            before = self.bridge.spent
            out = await asyncio.to_thread(self.execute, code)
            return replace(out, spent=self.bridge.spent - before)

    def close(self) -> None:
        """No hay nada que cerrar: el namespace vive en este proceso y se va con él.

        Existe para que el que arma un REPL lo cierre sin preguntar cuál le tocó.
        `Container.close` sí hace algo, y es el mismo nombre a propósito.
        """

    def execute(self, code: str) -> Output:
        """El `exec` pelado, síncrono, sin hilo ni lock: solo correr y capturar.

        Es público porque es la mitad del Workspace que se lleva el contenedor.
        `run` es la otra mitad, la de dónde corre: el hilo, el lock, el Bridge.
        Adentro de un proceso hijo no hay event loop que proteger, así que el
        hijo llama esto directo.
        """
        self._output.clear()
        self._wholes.clear()
        err = ""
        try:
            exec(code, self._globals)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
        notes = self._globals.get("notes")
        return Output(
            stdout="".join(self._output),
            err=err,
            notes=tuple(str(n) for n in notes) if isinstance(notes, list) else (),
        )
