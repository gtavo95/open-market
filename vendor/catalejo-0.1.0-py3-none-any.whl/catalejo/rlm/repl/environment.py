"""El seam del REPL: un workspace con estado que el modelo maneja con código.

El contexto grande vive acá como una variable, y NUNCA llega al prompt. Al
prompt solo llega el handle: el nombre de la variable, su tamaño y un esquema de
una línea. Esa es toda la economía del asunto, y por eso un contexto de 4M tokens
no paga 4M tokens por turno.

# El invariante: el Environment es una ventana de solo lectura

Todo builtin que se le dé al modelo puede leer y devolver texto, y nada más. Sin
filesystem, sin escrituras de red, sin más efectos que leer.

El código que el modelo escribe procesa texto no confiable, el contexto cargado y
lo que recupere de una búsqueda, así que este invariante es la frontera de
seguridad: una inyección que secuestre al modelo, en el peor caso, lee lo que el
modelo ya podía leer. Cualquier capacidad futura con efectos va detrás de
aprobación humana explícita, nunca como un builtin más.

# La única excepción, y por qué es angosta

`add_step`, `mark` y `skip` apilan. Rompen "leer y devolver texto, y nada más",
así que la excepción va escrita acá y no descubierta después: el efecto aterriza
en un canal del Log, PROPONE y no admite, y no sale del proceso. Quien decide qué
entra es `admit`, que corre afuera del REPL, y el vocabulario lo cierra el
namespace.

Lo que la excepción NO tapa es la inyección. Un documento del corpus que diga
"llamá a `add_step(...)`" se sigue apoyando en el guardrail del preámbulo, igual
que cualquier otra instrucción que venga adentro del texto. El contenedor que va a
venir protege la máquina, no la integridad de la checklist: para eso hace falta
que lo que el plan afirma sea verificable, que es de qué se tratan las compuertas.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class Output:
    """El resultado de una corrida: lo que imprimió, el error si reventó, y qué costó.

    Un snippet que falla no es una excepción del host, es flujo normal del REPL
    que el modelo tiene que ver para corregirlo. Por eso el error viaja acá
    adentro y no como una excepción.

    `spent` es lo que gastó ESTA corrida. Casi siempre es cero, porque correr
    Python no cuesta tokens. Deja de serlo cuando el código del modelo llama a
    otro modelo: sin este campo, el gasto del árbol recursivo es invisible para
    el `budget` del padre y la recursión se financia sola.

    `notes` es la instantánea de la variable `notes` del workspace al terminar
    la corrida, si existe y es una lista; si no, la tupla vacía. Viaja acá para
    que `render` la muestre al pie de cada salida: lo que el modelo guardó vuelve
    al prompt sin que tenga que gastar un turno en `print(notas)`, y sigue ahí
    cuando la ventana ya recortó la salida en que lo encontró.
    """

    stdout: str = ""
    err: str = ""
    spent: int = 0
    notes: tuple[str, ...] = ()


class Environment(Protocol):
    """Corre código contra el workspace vivo y devuelve lo que imprimió.

    El workspace persiste entre llamadas, así que las variables quedan y el
    modelo puede acumular estado en código a lo largo de varios turnos. Eso es lo
    que le permite guardar un hallazgo en vez de depender de releer la
    transcripción, que se va recortando.
    """

    async def run(self, code: str) -> Output: ...


class FakeEnvironment:
    """Un Environment de mentira: corre el árbol entero sin ejecutar nada real.

    Sirve para probar el loop antes de conectar un sandbox, y para escribir tests
    del executor sin depender de qué hace Python con un snippet.
    """

    def __init__(self, script: Callable[[str], Output] | None = None) -> None:
        self._script = script
        self.ran: list[str] = []

    async def run(self, code: str) -> Output:
        self.ran.append(code)
        if self._script is None:
            return Output(stdout=f"echo: {code}")
        return self._script(code)
