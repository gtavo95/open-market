"""El REPL: dónde corre el código que el modelo escribe, y qué tiene a mano ahí adentro.

Esta carpeta no sabe qué es una `Cell` ni un `Log`, y no toma nada de `core`. Es
la mitad que se puede mirar sin el álgebra: el Protocol, sus dos implementaciones
(en proceso y en proceso hijo) y el `grep`. Las células que la usan viven en
`cells/`, y la regla es que la dependencia va en una sola dirección: de ahí hacia
acá, nunca al revés.
"""

from .container import Container
from .environment import Environment, Output, FakeEnvironment
from .workspace import (
    HEADER,
    TOOLS,
    TOOLS_ONE_STEP,
    Bridge,
    Workspace,
    grep,
    tools_note,
    read_paths,
    seen_paths,
    read,
    paths,
    strip_accents,
)

# Las dos formas de un REPL con contexto adentro. Lo que las distingue es dónde corre el
# código; lo que comparten es lo que el que las arma necesita: `var`, `tools`, `bridge`,
# `run` y `close`. Es una unión y no un Protocol porque son dos y se llaman por nombre.
Repl = Workspace | Container

__all__ = [
    "Bridge",
    "Container",
    "Environment",
    "FakeEnvironment",
    "HEADER",
    "Output",
    "Repl",
    "TOOLS",
    "TOOLS_ONE_STEP",
    "Workspace",
    "grep",
    "paths",
    "read",
    "read_paths",
    "seen_paths",
    "strip_accents",
    "tools_note",
]
