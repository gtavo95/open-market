"""El turno con plan, con nombre: el planner antes del trabajo y después de cada vuelta.

Como `drive` y `orchestrate`, no le agrega nada al álgebra: es una función de
células a célula. Existe para que la forma tenga un lugar donde leerse, porque
la forma obvia está mal y conviene tener escrito por qué.

# La forma

    then(quiet(planner), loop(then(only(unfinished, work), planner), max_steps=rounds))

El planner corre una vez ANTES, para sembrar el plan y decirle al modelo qué
hacer, y una vez DESPUÉS de cada vuelta de trabajo, para juzgar lo que la vuelta
hizo y decidir si hay otra. `work` es lo que sea: un `drive` entero, un
`fanout` de buscadores, una redactora. Solo corre si el plan sigue abierto
(`only(unfinished, ...)`), así que un plan que el juez cerró antes de empezar
no le cuesta una llamada al modelo.

# Por qué no `loop(then(planner, work))`

Es la forma que uno escribe primero, y tiene dos fallas que salen del álgebra.
Con el planner primero, el trabajo de la ÚLTIMA vuelta nunca se juzga: el loop
corta después de `work`, y lo que el juez habría cerrado no queda en el canal.
Y el camino feliz cuesta dos vueltas, una para trabajar y otra solo para que el
planner confirme, así que `rounds` cuenta una de más. Con el planner después,
cada vuelta termina juzgada, `rounds=1` es "una vuelta de trabajo", y la del
final sale con su veredicto.

El planner de ANTES va en `quiet`: es el que siembra y habla, y su voto no
importa, porque con el plan recién sembrado siempre es CONTINUE y `then` lo
juntaría por máximo con el del loop. El de adentro es el que manda: DONE cuando
el juez cerró todo, y ahí el loop termina con DONE; CONTINUE mientras falte, y
el `max` con el DONE del executor sigue siendo CONTINUE, que es lo que quiere
decir "contestó, pero el plan dice que no".

# Qué cuesta

Una llamada al juez antes y una por vuelta; con `facts` no cuesta nada y un juez
por la red memoriza el turno. Y un turno del usuario por vuelta con el plan
abierto, el de `voice`. Agotar `rounds` es un `Fail("loop", "tope de pasos")`
con el voto en CONTINUE, como en cualquier loop: el que llamó se lleva la
última respuesta y sabe que el plan quedó abierto. Ahí la última voz queda al
final de la transcripción sin vuelta que la siga, y está bien que quede: dice
qué faltó, que es lo que quien lea la transcripción quiere saber.
"""

from __future__ import annotations

from catalejo.core import Cell, loop, only, quiet, then

from .cells.planner import PlanChannel, unfinished


def planned(
    planner: Cell,
    work: Cell,
    *,
    channel: PlanChannel = "steps",
    rounds: int = 2,
    budget: int | None = None,
    deadline: float | None = None,
) -> Cell:
    """`then(quiet(planner), loop(then(only(unfinished, work), planner)))`, con los papeles nombrados.

    `planner` es un `planner(...)` de `cells/planner.py` CON `voice`, sobre
    `channel`: es el que dice qué hacer y el único que vota. Sin voz no manda, y
    el loop termina en la primera vuelta con el voto del trabajo.

    `work` es la célula que hace: ve lo que llegó, la semilla y la voz del
    planner, y corre solo mientras el plan de `channel` tenga pasos abiertos.

    `rounds` es cuántas vueltas de trabajo como máximo; `budget` y `deadline`
    son los otros dos topes del `loop`, sobre el turno entero menos el planner
    de apertura.
    """
    turn = then(only(unfinished(channel), work), planner)
    return then(quiet(planner), loop(turn, max_steps=rounds, budget=budget, deadline=deadline))
