"""El reintento, que es del error y no del transporte.

Vive afuera de los adaptadores porque no tiene nada de específico de un proveedor:
mira si el error se declara transitorio y repite, con la espera al doble cada vez.
Lo que sí es de cada proveedor, y por eso queda adentro de cada adaptador, es QUÉ
cuenta como transitorio: un 503 en los dos, `MALFORMED_FUNCTION_CALL` en Gemini,
un turno sin `content` en OpenAI.

Lo que envuelve es el pedido Y el parseo, y ese es el arreglo que costó dos
preguntas de veinte. Antes el reintento vivía adentro del POST, que solo ve el
código HTTP: un 200 con el turno roto salía derecho a `Fail` y el loop cortaba con
cero turnos. Quien sabe si vale la pena repetir no es el transporte, es el error.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


class ProviderError(RuntimeError):
    """Lo que volvió de la API no sirve como turno.

    El worker la convierte en `Fail("model", ...)` con voto QUIET, así que el loop
    corta con el motivo a la vista en vez de seguir pidiéndole texto a un proveedor
    que no está contestando.

    `transient` dice si reintentar el MISMO pedido tiene chance de andar. Es una
    propiedad del error y no del transporte: un 503 y un turno cortado por
    MALFORMED_FUNCTION_CALL llegan por caminos distintos y los dos se reintentan,
    un 400 y un corte por SAFETY no.

    `billed` dice si el intento fallido igual se cobró: un 200 con el turno vacío o
    cortado trae su `usage`, y reintentarlo vuelve a pagar todo el razonamiento. Un
    503, un 429 o la red caída no cobran nada.
    """

    def __init__(self, message: str, *, transient: bool = False, billed: bool = False) -> None:
        super().__init__(message)
        self.transient = transient
        self.billed = billed


async def with_retries(
    request: Callable[[], Awaitable[T]], *, retries: int, backoff: float, paid: int | None = None
) -> T:
    """Repite mientras el error se declare transitorio, y al rendirse dice por qué.

    `request` es el pedido, sin argumentos, para poder repetirlo tal cual. `retries`
    son los reintentos después del primer pedido: `retries=2` son tres intentos.
    `backoff` son los segundos de espera antes del primer reintento, y se duplica
    en cada uno.

    `paid` es cuántas de esas repeticiones pueden ser de un intento que se cobró
    (`ProviderError.billed`); `None` es sin tope aparte. Un turno vacío de un modelo
    de razonamiento cuesta lo mismo que uno bueno, y una racha de cinco es pagar
    cinco turnos por ninguno: desde el 7 de octubre de 2026 agro lo deja en uno.

    El mensaje final conserva el último motivo. Sin eso, "la API no respondió"
    manda a leer los logs del proveedor para averiguar si fue cuota, red o un turno
    roto, que son tres arreglos distintos.

    Levanta la excepción de la MISMA clase que la que falló, así que quien llama
    sigue viendo `GeminiError` u `OpenAIError` y no una clase abstracta que no le
    dice contra qué estaba hablando.
    """
    wait = backoff
    last: ProviderError | None = None
    billed = 0
    attempts = 0
    for attempt in range(retries + 1):
        attempts += 1
        try:
            return await request()
        except ProviderError as e:
            if not e.transient:
                raise
            last = e
            billed += e.billed
        if paid is not None and billed > paid:
            break
        if attempt < retries:
            await asyncio.sleep(wait)
            wait *= 2
    if last is None:
        raise ProviderError(f"retries={retries} does not allow even one attempt")
    raise type(last)(f"the API did not respond ({attempts} attempts). {last}", billed=last.billed)
