"""Adaptador de OpenAI: la misma `Conversation` contra /chat/completions.

Habla Chat Completions y no la Responses API, y `base_url` es un parámetro, así
que este archivo sirve para todo lo que copia ese contrato: Groq, Together,
OpenRouter, vLLM, Ollama. La Responses API traería los ítems de razonamiento
cifrados para reenviarlos entre turnos, y acá no sirven: este repo no declara
herramientas y cada turno es prosa o un bloque de código, sin estado del lado del
proveedor.

El mapeo es la mitad que el de Gemini, y no por mérito nuestro. El formato ya se
parece al `core`: el sistema es un mensaje más en la lista, `Role` es un StrEnum
cuyos valores son literalmente los que espera la API, y dos turnos seguidos del
mismo rol se aceptan sin juntarlos, que en Gemini hubo que resolver a mano.

Existe por lo mismo que existe el `retries=4` de `agro.py`. Un proveedor que
devuelve turnos vacíos por rachas es un piso de fiabilidad que no se sube desde
acá, y tener el segundo adaptador convierte "esperemos que hoy conteste" en
cambiar una línea. Que las dos clases tomen los mismos parámetros no es
casualidad, es el requisito para que ese cambio sea de una línea.

# Cuál modelo

`gpt-5.6-luna` con esfuerzo bajo, que es el default del worker en `exp` desde su
A/B contra `gpt-5.4-mini`. Allá luna obliga a la Responses API porque
chat/completions devuelve 400 si se le pide razonamiento junto con function
tools. Acá ese choque no existe: este repo no declara herramientas en ninguna
parte, así que luna razona por chat/completions y `reasoning_effort` viaja como
un campo más.
"""

from __future__ import annotations

import os
import time
from typing import Any, cast

import httpx

from catalejo.core import Conversation, Message, Role

from .model import Reply
from .backoff import ProviderError, with_retries
from .usage import Usage, meters, metered

__all__ = ["OpenAI", "OpenAIError", "Usage", "from_completion", "metered", "to_messages"]

BASE = "https://api.openai.com/v1"
MODEL = "gpt-5.6-luna"

TRANSIENT = frozenset({408, 429, 500, 502, 503, 504})

TRANSIENT_CUTS = frozenset({"tool_calls", "function_call"})


class OpenAIError(ProviderError):
    """Lo que volvió de la API no sirve como turno.

    Hereda de `ProviderError`, que es lo que mira `with_retries`. Lo único que
    agrega es el nombre, y el nombre es la mitad del mensaje de error: el worker
    formatea `type(e).__name__`, así que un `Fail` dice contra qué proveedor se
    estaba hablando sin que nadie lo escriba a mano.
    """


def to_messages(conv: Conversation) -> list[dict[str, str]]:
    """La conversación tal cual, que acá es una lista de {role, content}.

    `Role` es un StrEnum con los mismos valores que usa la API, así que no hay
    traducción que hacer. Es una coincidencia afortunada y conviene decirla: si
    mañana el core gana un rol que la API no tiene, esto deja de ser un `.value`
    y pasa a ser un diccionario.

    Una conversación con puras instrucciones de sistema no es una pregunta. La
    API contestaría igual, inventando de qué hablar, y eso es peor que el error.
    """
    if not any(m.role is not Role.SYSTEM for m in conv):
        raise OpenAIError("conversation with no turns: the preamble alone is not a question")
    return [{"role": m.role.value, "content": m.text} for m in conv]


def from_completion(payload: dict[str, Any]) -> Reply:
    """Saca el turno y el gasto, o explica por qué no hay turno.

    Cuatro cosas que no son obvias.

    Un `refusal` viene en su propio campo con el `content` vacío. Leerlo es la
    diferencia entre "el modelo contestó vacío" y saber que se negó, que son dos
    problemas distintos y uno de los dos no se arregla reintentando.

    Cortar por `length` es un turno roto, no un turno corto. El bloque cercado
    queda sin cerrar, `extract_code` no lo corre, el executor lo lee como prosa y
    vota DONE: el agente devolvería media oración como respuesta final. No se
    reintenta, porque el mismo prompt vuelve a cortar en el mismo lugar.

    Un turno con `content` vacío y sin refusal es el mismo agujero que en Gemini.
    Los modelos de razonamiento pueden gastar todo el presupuesto de salida
    pensando y no escribir nada, y llega como un 200 perfectamente formado. Se
    reintenta porque el mismo pedido repetido a veces sale: contra Gemini,
    doce llamadas idénticas daban seis turnos buenos y seis vacíos.

    `spent` es `usage.total_tokens`, que ya incluye los tokens de razonamiento.
    Es lo que cobran, así que es lo que tiene que ver el presupuesto.
    """
    error = payload.get("error")
    if error:
        detail = error.get("message", error) if isinstance(error, dict) else error
        raise OpenAIError(f"the API returned an error: {detail}")
    choices = payload.get("choices") or []
    if not choices:
        raise OpenAIError("the API returned no answer: no choices")
    choice = choices[0]
    message = choice.get("message") or {}
    refusal = (message.get("refusal") or "").strip()
    if refusal:
        raise OpenAIError(f"the model refused: {refusal}")
    finish = choice.get("finish_reason") or "stop"
    if finish != "stop":
        raise OpenAIError(
            f"turn cut off by {finish}",
            transient=finish in TRANSIENT_CUTS,
            billed=True,
        )
    text = message.get("content")
    if not isinstance(text, str) or not text.strip():
        raise OpenAIError(
            "the model answered empty (turn without content: it is usually the whole "
            "output budget spent on reasoning)",
            transient=True,
            billed=True,
        )
    spent = int((payload.get("usage") or {}).get("total_tokens", 0))
    return Reply(Message(Role.ASSISTANT, text), spent=spent)


class OpenAI:
    """Un `Model` contra /chat/completions.

    Los parámetros son los mismos que los de `Gemini`, a propósito. `thinking`
    mapea a `reasoning_effort` en vez de a `thinkingLevel`, y el que llama no se
    entera: cambiar de proveedor es cambiar la clase.

    Qué valores acepta `reasoning_effort` lo decide el MODELO, no la API, y el
    error no lo dice. `gpt-5.6-luna` toma "low", "medium" y "high", y rechaza
    "minimal" con HTTP 400: doce de doce llamadas idénticas. Otros modelos sí lo
    toman, así que la constante no valida nada, solo va este párrafo. Un valor que
    el modelo no conoce se ve como un 400 seco, no como un default.

    `temperature` no se manda si no se pide, y acá no es una preferencia como en
    Gemini: los modelos de razonamiento rechazan cualquier valor que no sea 1.

    `max_output_tokens` va como `max_completion_tokens`. El viejo `max_tokens`
    sigue documentado pero los modelos de razonamiento lo rechazan, y el error
    que devuelven no dice cuál es el nombre nuevo.

    `base_url` es lo que hace que esto valga para más de un proveedor. La key se
    exige solo contra api.openai.com, porque un endpoint local no pide ninguna y
    obligar a inventarse una sería pedir un trámite por nada.
    """

    def __init__(
        self,
        model: str = MODEL,
        *,
        api_key: str | None = None,
        base_url: str = BASE,
        thinking: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
        timeout: float = 120.0,
        retries: int = 2,
        paid_retries: int | None = None,
        backoff: float = 1.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        key = api_key or os.environ.get("OPENAI_API_KEY", "")
        if not key and base_url == BASE:
            raise OpenAIError("OPENAI_API_KEY is missing")
        self.model = model
        self._url = f"{base_url.rstrip('/')}/chat/completions"
        self._headers = {"Content-Type": "application/json"}
        if key:
            self._headers["Authorization"] = f"Bearer {key}"
        self._retries = retries
        self._paid_retries = paid_retries
        self._backoff = backoff
        config: dict[str, Any] = {}
        if temperature is not None:
            config["temperature"] = temperature
        if max_output_tokens is not None:
            config["max_completion_tokens"] = max_output_tokens
        if thinking is not None:
            config["reasoning_effort"] = thinking
        self._config = config
        self._client = client or httpx.AsyncClient(timeout=timeout)
        self._owned = client is None
        self.usage = Usage()

    async def complete(self, conv: Conversation) -> Reply:
        """Un turno, reintentando lo que sea del momento.

        El reintento envuelve el pedido y el parseo, y por qué eso importa está
        contado en `backoff.py`.
        """
        body: dict[str, Any] = {
            "model": self.model,
            "messages": to_messages(conv),
            **self._config,
        }

        async def request() -> Reply:
            return from_completion(await self._post(body))

        return await with_retries(request, retries=self._retries, backoff=self._backoff, paid=self._paid_retries)

    async def _post(self, body: dict[str, Any]) -> dict[str, Any]:
        """Un solo intento. Marca lo que se puede repetir y deja que decida arriba.

        El reloj envuelve solo el POST: un intento que se cae por la red o por
        un 503 también se esperó, y `Usage.clock` lo cuenta igual.
        """
        t0 = time.monotonic()
        try:
            r = await self._client.post(self._url, json=body, headers=self._headers)
        except httpx.TransportError as e:
            raise OpenAIError(f"{type(e).__name__}: {e}", transient=True) from e
        finally:
            for u in meters(self.usage):
                u.clock(time.monotonic() - t0)
        if r.status_code != 200:
            raise OpenAIError(
                f"HTTP {r.status_code}: {r.text[:300]}",
                transient=r.status_code in TRANSIENT,
            )
        data = r.json()
        if not isinstance(data, dict):
            raise OpenAIError(f"the API returned {type(data).__name__}, not an object")
        for u in meters(self.usage):
            u.add(data.get("usage") or {})
        return cast(dict[str, Any], data)

    async def aclose(self) -> None:
        if self._owned:
            await self._client.aclose()
