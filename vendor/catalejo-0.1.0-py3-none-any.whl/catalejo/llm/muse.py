"""Muse Spark adapter (Meta's API): the same `Conversation` against /v1/responses.

It speaks the Responses API, the only one Meta exposes. Two differences from
`openai.py`: the system is not one more message but the `instructions` field, and
the response has no `choices` but an `output` list with items of several types
(`reasoning`, `message`), of which only the `output_text` ones matter.

As in the other adapters, this file declares no tools: each turn is prose or a
code block, and the API runs with `store: false`, with no state on the provider's
side.

`thinking` maps to `reasoning.effort`. The model decides which values it accepts
and the error does not say; "low" is the one that has been tried.

The key comes from `MUSE_API_KEY` or, failing that, from `MODEL_API_KEY`, the name
environments that already talk to Muse leave it under.
"""

from __future__ import annotations

import os
import time
from typing import Any, cast

import httpx

from catalejo.core import Conversation, Message, Role

from .backoff import ProviderError, with_retries
from .model import Reply
from .usage import Usage, meters

__all__ = ["Muse", "MuseError", "from_response", "to_request"]

BASE = "https://api.meta.ai/v1"
MODEL = "muse-spark-1.3-contributor"
KEYS = ("MUSE_API_KEY", "MODEL_API_KEY")

TRANSIENT = frozenset({408, 429, 500, 502, 503, 504})


class MuseError(ProviderError):
    """What came back from the API is no use as a turn. The name says who was being talked to."""


def to_request(conv: Conversation) -> dict[str, Any]:
    """`instructions` with the system messages joined, and `input` with the rest.

    A single user turn travels as a string, the simplest form and the one already
    tried against the API; several, as a list of {role, content}.

    A conversation of only instructions is not a question: the API would answer
    anyway, making up what to talk about, and that is worse than the error.
    """
    system = "\n\n".join(m.text for m in conv if m.role is Role.SYSTEM)
    turns = [m for m in conv if m.role is not Role.SYSTEM]
    if not turns:
        raise MuseError("conversation without turns: the preamble alone is not a question")
    body: dict[str, Any] = {"input": turns[0].text if len(turns) == 1 and turns[0].role is Role.USER
                            else [{"role": m.role.value, "content": m.text} for m in turns]}
    if system:
        body["instructions"] = system
    return body


def from_response(payload: dict[str, Any]) -> Reply:
    """Takes out the turn and the spend, or explains why there is no turn.

    A `status` other than `completed` is a broken turn. `incomplete` from
    `max_output_tokens` repeats the cut with the same prompt, so it is not
    retried; `failed` and `cancelled` are, because they belong to the moment.

    A turn without text is the hole of reasoning models: the whole output budget
    spent thinking, arriving as a well-formed 200. It is retried, and marked as
    billed because the reasoning was paid for.

    `spent` is `total_tokens`, which already includes the reasoning.
    """
    error = payload.get("error")
    if error:
        detail = error.get("message", error) if isinstance(error, dict) else error
        raise MuseError(f"the API returned an error: {detail}")
    status = payload.get("status") or "completed"
    if status != "completed":
        why = (payload.get("incomplete_details") or {}).get("reason", status)
        raise MuseError(f"response {status}: {why}", transient=status in ("failed", "cancelled"), billed=True)
    items = payload.get("output") or []
    refusal = "".join(c.get("refusal", "") for o in items if o.get("type") == "message"
                      for c in o.get("content") or [] if c.get("type") == "refusal").strip()
    if refusal:
        raise MuseError(f"the model refused: {refusal}")
    text = "".join(c.get("text", "") for o in items if o.get("type") == "message"
                   for c in o.get("content") or [] if c.get("type") == "output_text")
    if not text.strip():
        raise MuseError("the model answered empty (turn without text: usually the whole "
                        "output budget spent on reasoning)", transient=True, billed=True)
    usage = payload.get("usage") or {}
    spent = int(usage.get("total_tokens") or usage.get("input_tokens", 0) + usage.get("output_tokens", 0))
    return Reply(Message(Role.ASSISTANT, text), spent=spent)


def charge(own: Usage, usage: dict[str, Any]) -> None:
    """The Responses `usage` (input_tokens/output_tokens) on the adapter's account."""
    for u in meters(own):
        u.charge(
            input=int(usage.get("input_tokens", 0)),
            cached=int((usage.get("input_tokens_details") or {}).get("cached_tokens", 0)),
            output=int(usage.get("output_tokens", 0)),
            reasoning=int((usage.get("output_tokens_details") or {}).get("reasoning_tokens", 0)),
        )


class Muse:
    """A `Model` against /v1/responses. Same parameters as `OpenAI`, to change the class and nothing else."""

    def __init__(
        self,
        model: str | None = None,
        *,
        api_key: str | None = None,
        base_url: str = BASE,
        thinking: str | None = "low",
        max_output_tokens: int | None = 8000,
        timeout: float = 120.0,
        retries: int = 2,
        paid_retries: int | None = None,
        backoff: float = 1.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        key = api_key or next((os.environ[k] for k in KEYS if os.environ.get(k)), "")
        if not key:
            raise MuseError("missing MUSE_API_KEY (or MODEL_API_KEY)")
        self.model = model or os.environ.get("MUSE_MODEL", MODEL)
        self._url = f"{base_url.rstrip('/')}/responses"
        self._headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
        self._retries = retries
        self._paid_retries = paid_retries
        self._backoff = backoff
        config: dict[str, Any] = {"store": False}
        if max_output_tokens is not None:
            config["max_output_tokens"] = max_output_tokens
        if thinking is not None:
            config["reasoning"] = {"effort": thinking}
        self._config = config
        self._client = client or httpx.AsyncClient(timeout=timeout)
        self._owned = client is None
        self.usage = Usage()

    async def complete(self, conv: Conversation) -> Reply:
        """One turn, retrying whatever belongs to the moment (request and parsing together, as in `backoff.py`)."""
        body: dict[str, Any] = {"model": self.model, **to_request(conv), **self._config}

        async def request() -> Reply:
            return from_response(await self._post(body))

        return await with_retries(request, retries=self._retries, backoff=self._backoff, paid=self._paid_retries)

    async def _post(self, body: dict[str, Any]) -> dict[str, Any]:
        t0 = time.monotonic()
        try:
            r = await self._client.post(self._url, json=body, headers=self._headers)
        except httpx.TransportError as e:
            raise MuseError(f"{type(e).__name__}: {e}", transient=True) from e
        finally:
            for u in meters(self.usage):
                u.clock(time.monotonic() - t0)
        if r.status_code != 200:
            raise MuseError(f"HTTP {r.status_code}: {r.text[:300]}", transient=r.status_code in TRANSIENT)
        data = r.json()
        if not isinstance(data, dict):
            raise MuseError(f"the API returned {type(data).__name__}, not an object")
        charge(self.usage, data.get("usage") or {})
        return cast(dict[str, Any], data)

    async def aclose(self) -> None:
        if self._owned:
            await self._client.aclose()
