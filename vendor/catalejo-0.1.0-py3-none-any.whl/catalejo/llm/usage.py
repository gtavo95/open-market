"""La cuenta del proveedor: lo que cobró cada llamada, separado como lo cobra.

Vive aparte de los adaptadores porque la comparten. Nació en `openai.py`, cuando era
el único que la llevaba; con `anthropic.py` son dos, y el host abre un solo
`metered()` alrededor del turno sin saber contra cuál está hablando.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any


@dataclass
class Usage:
    """Los tokens que la API cobró, separados como los cobra: entrada, cacheada, escrita, salida.

    `spent` en cada `Reply` es `total_tokens`, un solo número, y alcanza para el
    presupuesto del loop pero no para el precio: la salida vale seis veces la
    entrada y la entrada cacheada un décimo (tabla del 16 de septiembre de 2026,
    luna: 0.20 / 0.02 / 1.20 dólares el millón). Un arm con más razonamiento
    puede subir 8% en tokens y bastante más en plata. Y la caché no se ve en
    `total_tokens` para nada: sin este contador no se sabe si el preámbulo, que
    es idéntico en todas las llamadas de una corrida, se está cobrando entero.

    `input` es TODA la entrada, cacheada y escrita incluidas, como la cuenta
    OpenAI; `cached` y `written` son partes de ella. Anthropic las informa por
    separado y su adaptador las suma, para que `input - cached - written` sea lo
    que se cobró a precio pleno con cualquier proveedor. `written` es la escritura
    a la caché, que solo Anthropic cobra aparte (1,25 veces la entrada); en OpenAI
    queda en cero.

    Vive en el adaptador y no en el `Log` porque es contabilidad del proveedor,
    no del turno: se acumula por instancia, sobre todas las llamadas incluidos
    los reintentos, que también se cobran.

    El tiempo va acá por la misma razón, y no como canal del Log: sumado bajo
    `fanout` mediría tiempo ocupado y no espera, porque dos buscadores de 10 s
    en paralelo son 10 s para el cliente y 20 en la suma. Medido en la fuente
    dice lo que dice, cuánto se esperó a la API, y el host lo compara con el
    reloj que pone alrededor del turno para saber qué parte del turno es el
    modelo y qué parte el REPL.

    `attempts` y `seconds` cuentan cada pedido, termine como termine; `calls`
    cuenta solo los que volvieron con un cuerpo, que son los que cobran. La
    diferencia son los 503, los cortes de red y los timeouts, y esos son justo
    los segundos que más importan: un pedido que cuelga hasta el `timeout`
    no cobra nada y el cliente lo espera entero. `slowest` es el intento
    más largo, para distinguir una API lenta pareja de un pedido colgado.
    """

    input: int = 0
    cached: int = 0
    output: int = 0
    reasoning: int = 0
    calls: int = 0
    attempts: int = 0
    seconds: float = 0.0
    slowest: float = 0.0
    written: int = 0

    def add(self, usage: dict[str, Any]) -> None:
        """El `usage` de chat/completions, tal como viene."""
        self.charge(
            input=int(usage.get("prompt_tokens", 0)),
            cached=int((usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)),
            output=int(usage.get("completion_tokens", 0)),
            reasoning=int((usage.get("completion_tokens_details") or {}).get("reasoning_tokens", 0)),
        )

    def charge(self, *, input: int, output: int, cached: int = 0, written: int = 0, reasoning: int = 0) -> None:
        """Una llamada cobrada, ya traducida: `input` con lo cacheado y lo escrito adentro."""
        self.calls += 1
        self.input += input
        self.cached += cached
        self.written += written
        self.output += output
        self.reasoning += reasoning

    def clock(self, secs: float) -> None:
        """Un intento terminado, como sea: lo que se esperó a la API."""
        self.attempts += 1
        self.seconds += secs
        self.slowest = max(self.slowest, secs)


_metered: ContextVar[Usage | None] = ContextVar("catalejo_metered", default=None)


@contextmanager
def metered() -> Iterator[Usage]:
    """Un `Usage` de lo que se cobre adentro del bloque, en cualquier adaptador que lleve cuenta.

    `usage` de un adaptador es de la instancia, y un servidor comparte la instancia
    entre los turnos que corren a la vez, así que su delta no dice qué fue de cada uno.
    Este dice: el host abre el bloque alrededor de un turno y cada llamada que
    ese turno origina suma acá además de en la instancia, reintentos incluidos.
    Viaja en un `ContextVar`, que las tareas, `asyncio.to_thread` y el puente
    del REPL (`run_coroutine_threadsafe` desde ese hilo) copian, así que los
    sub-agentes cuentan sin pasar nada a mano. Bloques anidados no se suman: el
    de adentro se lleva lo suyo y el de afuera no lo ve.
    """
    usage = Usage()
    token = _metered.set(usage)
    try:
        yield usage
    finally:
        _metered.reset(token)


def meters(own: Usage) -> tuple[Usage, ...]:
    """La cuenta de la instancia y, dentro de `metered()`, la del bloque."""
    scoped = _metered.get()
    return (own,) if scoped is None else (own, scoped)
