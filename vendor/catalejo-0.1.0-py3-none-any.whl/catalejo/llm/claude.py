"""Adaptador de Anthropic: la misma `Conversation` contra la Messages API, con el SDK oficial.

Acá sí va el SDK, al revés que en Gemini y OpenAI. Lo que se quiere de Claude son
sus funciones nativas (la caché de prompt con `cache_control`, el razonamiento
adaptativo con `effort`, `stop_details` cuando un clasificador se niega, el
`usage` con la lectura y la escritura de caché aparte) y el SDK las trae tipadas
y al día con la API. Los reintentos del SDK se apagan (`max_retries=0`): reintenta
`with_retries`, que es el que sabe qué intento se cobró (`backoff.py`).

# La caché

Dos marcas, de las cuatro que deja la API. Una sobre el sistema, que es el
preámbulo idéntico en todas las llamadas de una corrida. La otra es la automática
de arriba (`cache_control` en el pedido), que marca el último bloque: el loop del
RLM agrega turnos al final, así que la llamada siguiente lee de la caché todo lo
que la anterior escribió. Las dos se ven en `Usage.cached` y `Usage.written`.

# El razonamiento

`thinking` es el `effort` (low, medium, high, xhigh, max) y el razonamiento es
siempre adaptativo: el modelo decide cuánto piensa y si piensa. Los bloques de
razonamiento no vuelven en la conversación siguiente, porque la `Conversation`
es texto: cada turno es prosa o un bloque de código, sin herramientas, y la API
acepta un turno del asistente sin su razonamiento.
"""

from __future__ import annotations

import os
import time
from typing import Any

import anthropic
from anthropic.types import Message as ApiMessage

from catalejo.core import Conversation, Message, Role

from .backoff import ProviderError, with_retries
from .model import Reply
from .usage import Usage, meters

MODEL = "claude-haiku-5-5"

TRANSIENT = frozenset({408, 409, 429, 500, 502, 503, 504, 529})

MAX_TOKENS = 16000
"""El techo de salida, razonamiento incluido. Sin streaming, el que recomienda la documentación."""


class ClaudeError(ProviderError):
    """Lo que volvió de la API no sirve como turno.

    Hereda de `ProviderError`, que es lo que mira `with_retries`. Lo único que
    agrega es el nombre, y el nombre es la mitad del mensaje de error: el worker
    formatea `type(e).__name__`, así que un `Fail` dice contra qué proveedor se
    estaba hablando sin que nadie lo escriba a mano.
    """


def to_request(conv: Conversation) -> dict[str, Any]:
    """Parte la conversación en sistema y turnos, como Gemini.

    El sistema va aparte y con su marca de caché. Dos turnos seguidos del mismo
    rol se juntan en uno con varios bloques, que es el caso de `window`: mete el
    aviso de recorte como USER justo después de la pregunta.

    El último turno tiene que ser del usuario. Los modelos actuales rechazan con
    400 un turno del asistente al final (el prefill), y en este repo eso no pasa:
    si pasa es un bug de quien armó la conversación, y mejor que lo diga acá.
    """
    system = "\n\n".join(m.text for m in conv if m.role is Role.SYSTEM)
    messages: list[dict[str, Any]] = []
    for m in conv:
        if m.role is Role.SYSTEM:
            continue
        role = "assistant" if m.role is Role.ASSISTANT else "user"
        block = {"type": "text", "text": m.text}
        if messages and messages[-1]["role"] == role:
            messages[-1]["content"].append(block)
        else:
            messages.append({"role": role, "content": [block]})
    if not messages:
        raise ClaudeError("conversation with no turns: the preamble alone is not a question")
    if messages[-1]["role"] != "user":
        raise ClaudeError("the conversation ends on the assistant: the API does not accept prefill")
    request: dict[str, Any] = {"messages": messages}
    if system:
        request["system"] = [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}]
    return request


def from_message(response: ApiMessage) -> Reply:
    """Saca el turno y el gasto, o explica por qué no hay turno.

    Tres cosas que no son obvias.

    Los bloques de razonamiento (`thinking`) vienen antes del texto y no son la
    respuesta: se lee por tipo, nunca por posición. Concatenarlos rompería el
    contrato de terminación, igual que en Gemini.

    Un `refusal` es un 200 con `stop_details`: un clasificador se negó. Se cobra
    y no se reintenta, porque el mismo pedido se vuelve a negar; la categoría va
    en el mensaje, que es lo que dice si fue el prompt o el tema.

    Cortar por `max_tokens` es un turno roto, no un turno corto, y no se reintenta:
    el mismo pedido vuelve a cortar. Un texto vacío con `end_turn` sí, como en los
    otros dos: el razonamiento se comió el turno y repetir a veces sale.
    """
    stop = response.stop_reason or "end_turn"
    if stop == "refusal":
        details = response.stop_details
        category = (details.category if details else None) or "no category"
        raise ClaudeError(f"the model refused ({category})", billed=True)
    if stop not in ("end_turn", "stop_sequence"):
        raise ClaudeError(f"turn cut off by {stop}", billed=True)
    text = "".join(b.text for b in response.content if b.type == "text")
    if not text.strip():
        raise ClaudeError("the model answered empty", transient=True, billed=True)
    u = response.usage
    spent = u.input_tokens + (u.cache_read_input_tokens or 0) + (u.cache_creation_input_tokens or 0) + u.output_tokens
    return Reply(Message(Role.ASSISTANT, text), spent=spent)


def charge(usage: Usage, response: ApiMessage) -> None:
    """Suma el `usage` de la respuesta: `input_tokens` de Anthropic es solo lo que no tocó la caché."""
    u = response.usage
    read = u.cache_read_input_tokens or 0
    written = u.cache_creation_input_tokens or 0
    details = u.output_tokens_details
    usage.charge(
        input=u.input_tokens + read + written,
        cached=read,
        written=written,
        output=u.output_tokens,
        reasoning=(details.thinking_tokens or 0) if details else 0,
    )


class Claude:
    """Un `Model` contra la Messages API.

    Los parámetros son los mismos que los de `Gemini` y `OpenAI`, a propósito:
    cambiar de proveedor es cambiar la clase. `thinking` mapea a `effort`.

    `temperature` no se manda si no se pide, y en los modelos actuales no es una
    preferencia: Haiku 5.5 rechaza con 400 todo valor que no sea 1.

    `client` es para los tests y para compartir conexiones; si no viene, se arma
    uno con la clave de `ANTHROPIC_API_KEY` y sin reintentos propios.

    `workspace` es para una clave que no está asignada a un workspace: la API
    devuelve 400 si no viene el header `anthropic-workspace-id`. Vacío, se lee
    `ANTHROPIC_WORKSPACE_ID`; una clave del workspace no lo necesita.
    """

    def __init__(
        self,
        model: str = MODEL,
        *,
        api_key: str | None = None,
        workspace: str | None = None,
        thinking: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
        timeout: float = 120.0,
        retries: int = 2,
        paid_retries: int | None = None,
        backoff: float = 1.0,
        client: anthropic.AsyncAnthropic | None = None,
    ) -> None:
        key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not key and client is None:
            raise ClaudeError("ANTHROPIC_API_KEY is missing")
        self.model = model
        self._retries = retries
        self._paid_retries = paid_retries
        self._backoff = backoff
        config: dict[str, Any] = {
            "max_tokens": max_output_tokens or MAX_TOKENS,
            "thinking": {"type": "adaptive"},
            "cache_control": {"type": "ephemeral"},
        }
        if thinking is not None:
            config["output_config"] = {"effort": thinking}
        if temperature is not None:
            config["temperature"] = temperature
        self._config = config
        workspace = workspace or os.environ.get("ANTHROPIC_WORKSPACE_ID", "")
        headers = {"anthropic-workspace-id": workspace} if workspace else None
        self._client = client or anthropic.AsyncAnthropic(
            api_key=key, timeout=timeout, max_retries=0, default_headers=headers
        )
        self._owned = client is None
        self.usage = Usage()

    async def complete(self, conv: Conversation) -> Reply:
        """Un turno, reintentando lo que sea del momento.

        El reintento envuelve el pedido y el parseo, y por qué eso importa está
        contado en `backoff.py`.
        """
        body: dict[str, Any] = {"model": self.model, **to_request(conv), **self._config}

        async def request() -> Reply:
            return from_message(await self._post(body))

        return await with_retries(request, retries=self._retries, backoff=self._backoff, paid=self._paid_retries)

    async def _post(self, body: dict[str, Any]) -> ApiMessage:
        """Un solo intento. Marca lo que se puede repetir y deja que decida arriba.

        Los errores del SDK se traducen por clase, de la más específica a la más
        ancha: un `APIStatusError` trae el código, y la red caída o el timeout no
        traen ninguno y se repiten.
        """
        t0 = time.monotonic()
        try:
            response: ApiMessage = await self._client.messages.create(**body)
        except anthropic.APIStatusError as e:
            raise ClaudeError(f"HTTP {e.status_code}: {str(e.message)[:300]}", transient=e.status_code in TRANSIENT) from e
        except anthropic.APIConnectionError as e:
            raise ClaudeError(f"{type(e).__name__}: {e}", transient=True) from e
        finally:
            for u in meters(self.usage):
                u.clock(time.monotonic() - t0)
        for u in meters(self.usage):
            charge(u, response)
        return response

    async def aclose(self) -> None:
        if self._owned:
            await self._client.close()
