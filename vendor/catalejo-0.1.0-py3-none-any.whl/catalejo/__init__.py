"""catalejo: un Recursive Language Model en tres capas.

`core` es el álgebra: `Log`, las células y los combinadores. `llm` es el puerto
del modelo y sus adaptadores. `rlm` es el agente: el REPL donde corre el código
que el modelo escribe, las células de un turno, y `recurse`/`drive` que los
juntan. Lo que se re-exporta acá es lo que define la librería: el motor y los
puertos. Un proveedor concreto (`Gemini`, `OpenAI`) se importa de `catalejo.llm`,
porque es una implementación del puerto y no parte del diseño.
"""

from importlib.metadata import PackageNotFoundError, version

from .core import Log, Message, Role, fanout, loop, retry, then
from .llm import Model, Provider
from .rlm import Handle, Workspace, drive, executor, grounded, recurse, worker

try:
    __version__ = version("catalejo")
except PackageNotFoundError:  # importado desde el árbol sin instalar
    __version__ = "0.0.0"

__all__ = [
    "Handle",
    "Log",
    "Message",
    "Model",
    "Provider",
    "Role",
    "Workspace",
    "__version__",
    "drive",
    "executor",
    "fanout",
    "grounded",
    "loop",
    "recurse",
    "retry",
    "then",
    "worker",
]
